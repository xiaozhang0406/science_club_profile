﻿#!/usr/bin/python3
# -*- coding: UTF-8 -*-

# 所有的独立程序都建议写第一行(我没记错的话，这个叫shebang)。这样对跨系统运行有帮助。
# 参见https://www.cnblogs.com/z-x-y/p/11445650.html

# 所有文件都建议写第二行。它设置了文件的编码格式，设置成utf-8对国际化有帮助。

"""
说明：
1.本计算器默认染色体组数为2，不支持修改染色体组数。
2.如果要退出，请输入exit,然后回车。您可以直接输入数字马上进行简单的计算， 您输入的数字将会保存为[等位基因数]
3.强烈建议使用Python3.8以上的版本运行，否则会导致效率严重下降！
"""

import sys
from os import chdir, getcwd, system
from pathlib import Path
from time import time_ns
from traceback import print_exc

# 计时
_d1 = time_ns()


from MendelLib.mendel_meta import (version_maker, GLOBALS, number_, father_, mother_, _site, gui_)
from MendelLib.mendel_helper import isIllegalCommand, isIllegalGenes, check_upd
from MendelLib.mendel_cmd_pack import __func__, calculate
GLOBALS[gui_].destroy()

from MStzzfTools.printer import *
from MStzzfTools.decorators import BoolControl, _do_this, _pass

try:
    if sys.version_info.major != 3 or sys.version_info.minor < 8:
        ms_warn("<\x1b[33m__警告__\x1b[0m:此程序的解释器版本应该大于等于\x1b[33m3.8\x1b[0m！>", True)
except:
    pass

__author__ = "MStzzf"
chdir(Path(__file__).resolve().parent)
print("workspace@" + getcwd(), "platform@" + PLATFORM)
print("欢迎使用孟德尔计算器！")
print(__doc__)


@BoolControl(0, "PromoteCmdIfIllegalTyping", _do_this, _pass)
def cmd_promote():
    print("您是否正在寻找以下命令之一？")
    for s in __func__:
        if GLOBALS[number_] in s:
            print("\t" + s)
    print("如果上述结果中没有您想要的命令，请输入help来获取所有命令列表。")


def mendel():
    check_upd()
    if PLATFORM == "Windows":
        system("title 孟德尔计算器-" + version_maker())
    dt = round((time_ns() - _d1) / 1000000, 3)
    if dt > 1000:
        info = f"[信息]启动[孟德尔计算器]共使用{str(round(dt / 1000, 2))}秒！"
    else:
        info = f"[信息]启动[孟德尔计算器]共使用{str(dt)}毫秒！"
    print(info)

    '''主程序'''
    while True:

        GLOBALS[number_] = ms_input("MendelCalculator>")

        if GLOBALS[number_] in ["exit"]:
            break
        # # 测试使用：编译时千万不要把这个也一块搞上去了。
        # elif "py$" in GLOBALS[number_]:
        #     try:
        #         exec(GLOBALS[number_].replace("py$", ""), globals())
        #     except:
        #         print_exc()
        #     GLOBALS[argv_not_given_] = True
        #     continue
        elif not GLOBALS[number_].isdigit():
            try:
                __func__[GLOBALS[number_]]()
            except KeyError:
                ms_error("[错误]没有这个命令！！")
                cmd_promote()
            except:
                ms_error("[错误]在执行时出现异常！")
                print_exc()
            continue

        if isIllegalCommand(GLOBALS[number_]):
            continue

        print("请输入基因型:")
        GLOBALS[father_] = ms_input("第1组(父本)>")
        GLOBALS[mother_] = ms_input("第2组(母本)>")
        if isIllegalGenes(GLOBALS[number_], GLOBALS[father_], GLOBALS[mother_]):
            continue
        calculate()

        # todo: 管理存档。
        # todo: die_filter

    print("Exiting...")


def main():
    try:
        mendel()
    except Exception as e:
        if isinstance(e, SystemExit):
            ms_warn("[信息]检测到发生的错误为SystemExit，如果你是手动退出，请无视这个错误。")
        elif isinstance(e, EOFError):
            ms_warn("[信息]检测到发生的错误为EOFError，如果你输入时按住Ctrl+Z并回车则可能导致此错误。如果这个错误是手动触发的，请无视这个错误。")
        ms_error("[错误]在运行孟德尔计算器的时候发生了错误，信息如下！")
        ms_error("workspace@" + getcwd()+"  platform@" + PLATFORM)
        print_exc()
        ms_green(f"[提示]如果您觉得这是个漏洞，请在[{_site}issues/]告诉我们，并提供以上信息，我们感激不尽。")
        input("<按回车键退出>")

# 这个判断语句的意思是如果这个文件作为主程序运行，则。。。
if __name__ == '__main__':
    main()
