"""提供操作台命令和基础字符操作"""
from typing import List

from MStzzfTools.mtype_util import ListToDict, DictToList
from MStzzfTools.printer import PLATFORM, RELEASE
from MendelLib.mendel_helper import *



def analyzeChessboard9(gla_list1: List[str], gla_list2: List[str],
                       fp: str, mp: str,
                       callbacks: Callbacks.AnalyzeChb = Callbacks.AnalyzeChb(),
                       echo=True):
    """参见：analyzeChessboard
    把长度为9的基因分离成一个长度为8的和一个长度为1的，
    这样计算时，先计算8对的通过8对的计算出9对的，速度为原始方法的3倍左右。"""
    gla_dict_f = rater(ListToDict(gla_list1, callbacks.gamete_l2d))
    gla_dict_m = rater(ListToDict(gla_list2, callbacks.gamete_l2d))

    part1718 = get_alpha_ignore_case(fp)[0]

    AA = (part1718 * 2).upper()
    Aa = part1718.upper() + part1718
    aa = part1718 * 2

    callbacks.onmatch()
    gla_list = []
    gla_list1 = DictToList(gla_dict_f)
    gla_list2 = DictToList(gla_dict_m)

    for oi in gla_list1:
        for oj in gla_list2:
            gla_list.append(matcher(oi, oj))

    old_dict = rater(ListToDict(gla_list, callbacks.match_l2d))

    gla_dict = {}

    # [AA AA] [AA Aa]$ [AA aa]$
    # [Aa Aa] [Aa aa]$
    # [aa aa]

    callbacks.on_finalise.onstart(old_dict)

    if isAA(fp) == True and isAA(mp) == True:
        for index, k in enumerate(old_dict):
            gla_dict[k + AA] = old_dict[k]
            callbacks.on_finalise.foreach(index, k)

    elif (isAA(fp) == True and isAa(mp) == True) and (isAa(fp) == True and isAA(mp) == True):
        for index, k in enumerate(old_dict):
            gla_dict[k + AA] = old_dict[k]
            gla_dict[k + Aa] = old_dict[k]
            callbacks.on_finalise.foreach(index, k)

    elif (isAA(fp) == True and isaa(mp) == True) or (isaa(fp) == True and isAA(mp) == True):
        for index, k in enumerate(old_dict):
            gla_dict[k + Aa] = old_dict[k]
            callbacks.on_finalise.foreach(index, k)

    elif isAa(fp) == True and isAa(mp) == True:
        for index, k in enumerate(old_dict):
            gla_dict[k + AA] = old_dict[k]
            gla_dict[k + Aa] = old_dict[k] * 2
            gla_dict[k + aa] = old_dict[k]
            callbacks.on_finalise.foreach(index, k)

    elif (isAa(fp) == True and isaa(mp) == True) and (isaa(fp) == True and isAa(mp) == True):
        for index, k in enumerate(old_dict):
            gla_dict[k + Aa] = old_dict[k]
            gla_dict[k + aa] = old_dict[k]
            callbacks.on_finalise.foreach(index, k)

    elif isaa(fp) == True and isaa(mp) == True:
        for index, k in enumerate(old_dict):
            gla_dict[k + aa] = old_dict[k]
            callbacks.on_finalise.foreach(index, k)

    if echo:
        result_printer(gla_dict_f, "父本")
        result_printer(gla_dict_m, "母本")
        result_printer(gla_dict, "结果")

    return gla_dict_f, gla_dict_m, gla_dict


def analyzeChessboard(gla_list1: list, gla_list2: list,
                      callbacks: Callbacks.AnalyzeChb = Callbacks.AnalyzeChb(),
                      echo=True):
    """用生物中的棋盘法进行结果的分析，输入一个列表，返回一个字典。
    父本：Aabb 母本：aaBb
        父本配子 Ab     ab
    母本配子
    aB          AaBb  aaBb
    ab          Aabb  aabb
    """
    '''用集合在在字典中创建不重复的元素'''
    f_dict = rater(ListToDict(gla_list1, callbacks.gamete_l2d))
    m_dict = f_dict if gla_list1 == gla_list2 else rater(ListToDict(gla_list2, callbacks.gamete_l2d))

    if echo:
        result_printer(f_dict, '父本配子')
        result_printer(m_dict, '母本配子')

    callbacks.onmatch()

    gla_list = []
    if gla_list1.count(gla_list1[0]) == len(gla_list1) and gla_list2.count(gla_list2[0]) == len(gla_list2):
        # 针对全部都是小写或者大写而优化。>9第1组(父本)>aa...ii第2组(母本)>aa...ii[信息]输出完毕共使用3.004毫秒！
        gla_list.append(matcher(gla_list1[0], gla_list2[0]))
    else:
        gla_list1 = DictToList(f_dict)
        gla_list2 = DictToList(m_dict)
        for oi in gla_list1:
            for oj in gla_list2:
                gla_list.append(matcher(oi, oj))

    gla_dict = rater(ListToDict(gla_list, callbacks.match_l2d))

    if echo:
        result_printer(gla_dict, '子代')

    return f_dict, m_dict, gla_dict


def result_printer(result_list: dict, prefix):
    """将结果以更让人可接受的方式输出，Win10版本的还有颜色高亮。"""
    x = 0
    y = 0
    if PLATFORM == "Windows" and RELEASE == "10":
        print("\x1b[33m%s:\x1b[0m" % prefix)
        for key in result_list:
            x += 1
            if x == 1:
                print('\x1b[33m[{}]\x1b[0m'.format(y * 5), end='')
                print("\x1b[0m[{}]={}\x1b[0m".format(key, result_list[key]), end=' ')
            elif x == 5:
                print("\x1b[0m[{}]={}\x1b[0m".format(key, result_list[key]))
                y += 1
                x = 0
            else:
                print("\x1b[0m[{}]={}\x1b[0m".format(key, result_list[key]), end=' ')
    else:
        print("%s:" % prefix)
        for key in result_list:
            x += 1
            if x == 1:
                print('[{}]'.format(y * 5), end='')
                print("[{}]={}".format(key, result_list[key]), end=' ')
            elif x == 5:
                print("[{}]={}".format(key, result_list[key]))
                y += 1
                x = 0
            else:
                print("[{}]={}".format(key, result_list[key]), end=' ')

    print()

