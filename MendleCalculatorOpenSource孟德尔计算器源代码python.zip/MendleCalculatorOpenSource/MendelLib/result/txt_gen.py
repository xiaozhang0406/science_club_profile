from os import getcwd, chdir
from pathlib import Path

from MendelLib.mendel_meta import f_, m_, r_
from MendelLib.result.result_gen_helper import write_file, get_save_info


def maker_helper(result_list: dict, prefix: str) -> str:
    x = 0
    y = 0
    result_str = "%s:\n" % prefix
    for key in result_list:
        x += 1
        if x == 1:
            result_str += '[{}]'.format(y * 5)
            result_str += "[{}]={} ".format(key, result_list[key])
        elif x == 5:
            result_str += "[{}]={}\n\n".format(key, result_list[key])
            y += 1
            x = 0
        else:
            result_str += "[{}]={} ".format(key, result_list[key])

    return result_str + "\n"


def result_str_maker(result_list: tuple or list) -> str:
    """将结果以更让人可接受的方式构建
    result_list -> (father:dict, mother:dict, result:dict)
    """
    if isinstance(result_list, dict):
        s = maker_helper(result_list[f_], "父本配子") + \
            maker_helper(result_list[m_], "母本配子") + \
            maker_helper(result_list[r_], "结果")
    else:
        s = maker_helper(result_list[0], "父本配子") + \
            maker_helper(result_list[1], "母本配子") + \
            maker_helper(result_list[2], "结果")

    return s


def txt_gen_main(parent: list, analyzed: list, p: str, need_cwd: bool = False):
    """
    parent: list    -> (father: str, mother: str)
    analyzed: list  -> (f: dict, m: dict, r: dict)
    """
    pa = f"父本:[{parent[0]}]\t母本:[{parent[1]}]\n"
    s = pa + result_str_maker(analyzed)

    if need_cwd:
        write_file(f"./saves/{p}.txt", s)
    else:
        write_file(p, s)
    print("[信息][%s]已生成完毕" % p)


def txt_gen_from_save_main(sn: str, fn: str = "result", need_cwd: bool = False):
    """
    parent: list    -> (father: str, mother: str)
    analyzed: list  -> (f: dict, m: dict, r: dict)
    """
    fn = fn + ".txt" if not fn.endswith(".txt") else fn
    num, author, credit, fa, mo, fr, mr, r = get_save_info(sn)
    pa = f"父本:[{fa}]\t母本:[{mo}]\n"
    c = f"作者:{author}\n注释:{credit}\n"
    s = c + pa + result_str_maker((fr, mr, r))
    if need_cwd:
        write_file(f"./saves/{sn}/result/{fn}.txt", s)
    else:
        write_file(fn, s)


if __name__ == '__main__':
    chdir(Path(__file__).resolve().parent.parent.parent)
    print(getcwd())
    txt_gen_main(["Aa", "Aa"],
                 [{"A": 1, "a": 1}, {"A": 1, "a": 1}, {"AA": 1, "Aa": 2, "aa": 1}],
                 "./a.txt"
                 )
    txt_gen_from_save_main(
        "9t",
        "./saves/9t/aa.txt",
    )
