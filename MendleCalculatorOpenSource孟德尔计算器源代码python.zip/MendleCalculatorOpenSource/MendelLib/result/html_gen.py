"""使用html语言展示结果
使用的主题来自jetbrains s.r.o.公司旗下的工具。
"""
from os import getcwd

from MendelLib.mendel_meta import version_maker
from MendelLib.result.result_gen_helper import get_save_info, write_file


def gen_lines(data: dict, prefix: str):
    global _html_base_lnend, _html_base_ct, _html_base_ln, _html_base_prf
    x = 0
    y = 0
    s = _html_base_prf % prefix
    base_len = len(list(data.keys())[0] + str(list(data.values())[0])) + 1
    for key in data:
        x += 1
        blank = " " * (base_len - (len(key + str(data[key]))))
        if x == 1:
            s += _html_base_ln % ("[" + str(y * 5) + "]" + " " * (6 - (len(str(y * 5)))))
            s += _html_base_ct % (key, str(data[key]) + blank)
        elif x == 5:
            s += _html_base_ct % (key, str(data[key]) + blank)
            s += _html_base_lnend
            y += 1
            x = 0
        else:
            s += _html_base_ct % (key, str(data[key]) + blank)
    s += _html_base_lnend
    # print(s)
    return s


def html_gen_main(parent: list, analyzed: list, p: str, need_cwd: bool = False):
    """
    parent: list    -> (father: str, mother: str)
    analyzed: list  -> (f: dict, m: dict, r: dict)
    """
    global _html_base, _html_base_sv
    s = _html_base
    s = s.replace("$$version", version_maker())
    s = s.replace("$$file_name", p.replace(getcwd().replace("\\", "/"), ""))
    s = s.replace("$$father_gene", parent[0])
    s = s.replace("$$mother_gene", parent[1])
    b = gen_lines(analyzed[0], "父本配子：")
    c = gen_lines(analyzed[1], "母本配子：")
    d = gen_lines(analyzed[2], "结果：")
    s = s.replace("$$content", b + c + d)
    if need_cwd:
        write_file(f"./saves/{p}.html", s)
    else:
        write_file(p, s)


def html_gen_from_save_main(sn: str, fn: str = "result", need_cwd: bool = False):
    """
    parent: list    -> (father: str, mother: str)
    analyzed: list  -> (f: dict, m: dict, r: dict)
    """
    global _html_base, _html_base_sv
    fn = fn + ".html" if not fn.endswith(".html") else fn
    num, author, credit, fa, mo, fr, mr, r = get_save_info(sn)

    s = _html_base
    s = s.replace("$$version", version_maker())
    s = s.replace("$$file_name", fn)
    s = s.replace("$$father_gene", fa)
    s = s.replace("$$mother_gene", mo)

    sv = _html_base_sv
    sv = sv.replace("$$save_name", sn)
    sv = sv.replace("$$num", str(num))
    if author is None:
        sv = sv.replace("$$author", "null")
    else:
        sv = sv.replace("$$author", author)
    sv = sv.replace("$$credit", credit)

    b = gen_lines(fr, "父本配子：")
    c = gen_lines(mr, "母本配子：")
    d = gen_lines(r, "结果：")
    s = s.replace("$$content", sv + b + c + d)

    if need_cwd:
        write_file(f"./saves/{sn}/result/{fn}.html", s)
    else:
        write_file(fn, s)


_html_base = """<!-由孟德尔计算器生成, 版本V$$version-!>
<html>
<head>
<title>$$file_name</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
.white { color: #a9b7c6; font-size: 20}
.green { color: #6a8759;}
.ln { color: #606366; font-size: 20; font-weight: normal; font-style: normal; }
</style>
</head>
<body bgcolor="#2b2b2b">
<table CELLSPACING=0 CELLPADDING=5 COLS=1 WIDTH="100%" BGCOLOR="#606060" >
<tr><td><center>
    <font face="Arial, Helvetica" color="#000000" size="20">$$file_name</font>
</center></td></tr></table>

<pre>
    <font face="Arial, Helvetica" color="#6a8759" size="6">father: $$father_gene    mother: $$mother_gene</font>
$$content
</pre>
</body>
</html>
"""
_html_base_sv = """
    <font face="Arial, Helvetica" color="#a5c261" size="4">
    来自: $$save_name
    等位基因数: $$num   作者: $$author
    注释: $$credit
    </font>"""
_html_base_prf = """\t<font face="Arial, Helvetica" color="#a5c261" size="5">%s</font>\n"""
_html_base_ln = """\t<a><span class="ln">%s</span></a><span class="white">"""
_html_base_ct = """[<span class="gold">%s</span>]=%s  """
_html_base_lnend = "</span>\n"

if __name__ == '__main__':
    print(getcwd())
    '''html_gen_main(["Aa", "Aa"],
                  [{"A": 1, "a": 1}, {"A": 1, "a": 1}, {"AA": 1, "Aa": 2, "aa": 1}],
                  "./a.html"
                  )'''
    html_gen_from_save_main(
        "9t",
        "./saves/6t/aa.html",
    )
