"""允许导入上一级模块。"""
__author__ = "MStzzf"

from sys import path as spath

spath.append("..")
