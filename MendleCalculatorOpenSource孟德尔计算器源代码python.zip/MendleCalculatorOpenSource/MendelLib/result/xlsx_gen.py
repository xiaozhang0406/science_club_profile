"""提供结果输出函数"""
from pathlib import Path

from MendelLib.extensible import expand, _FORMATS
from MendelLib.mendel_meta import GLOBALS, saves_loaded_, save_name_
from MendelLib.result.result_gen_helper import get_save_info

from MStzzfTools.decorators import DisableCondition
from MStzzfTools.printer import ms_warn, ms_error

isOpenpyxlExist = True

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font
except:
    ms_warn("<\x1b[33m__警告__\x1b[0m:如果要使用输出为xlsx结果的功能，需要安装\x1b[33mopenpyxl\x1b[0m库！>", True)
    isOpenpyxlExist = False

_import_error = "[错误]此函数已被禁用！"

@DisableCondition(not isOpenpyxlExist, _import_error)
def load():
    wb = Workbook()
    ws = wb.active
    return ws, wb

@DisableCondition(not isOpenpyxlExist, _import_error)
def process(f, m, r):
    """处理获得的数据"""
    ped_data = []
    length = len(m)
    n = 1
    while n <= length:
        ped_data.append([])
        n += 1

    f_l = list(f.keys())
    m_l = list(m.keys())
    r_l = list(r.keys())
    n = 0
    while n <= length - 1:
        ped_data[n].extend([f_l[n], f[f_l[n]], m_l[n], m[m_l[n]], r_l[n], r[r_l[n]]])
        n += 1

    length = len(r)
    while n <= length - 1:
        ped_data.append(["", "", "", "", r_l[n], r[r_l[n]]])
        n += 1

    return ped_data


def write(ped_data: list, ws, father, mother):
    """写入文件"""
    ws.append(["父本", father, "母本", mother])
    ws.append(["父本配子", "相对数量", "母本配子", "相对数量", "结果", "相对数量"])
    for e in ped_data:
        ws.append(e)
    if len(father) > 4:
        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['C'].width = 20
        ws.column_dimensions['E'].width = 22


@DisableCondition(not isOpenpyxlExist, _import_error)
def save_file_cwd(wb, path: Path):
    """保存文件"""
    path = str(path)
    try:
        wb.save(path)
    except FileNotFoundError as e:
        ms_error(f"[错误]路径[{path}]似乎不存在")
        raise Exception(str(e))
    else:
        print(f"[信息][{path}]已被保存！")


if isOpenpyxlExist:
    red_bold_font = Font(name='黑体', size=15)


@DisableCondition(not isOpenpyxlExist, _import_error)
def xlsx_gen_from_save_main(sn: str, fn: str = "result", need_cwd=False):
    num, author, credit, fa, mo, fr, mr, r = get_save_info(sn)
    father = fa[:len(list(r.keys())[0])]
    mother = mo[:len(list(r.keys())[0])]
    ws, wb = load()
    ped_data = process(fr, mr, r)
    ws.append(["来自：", sn, "等位基因数：", num, "作者：", author, "注释：", credit])
    write(ped_data, ws, father, mother)
    if need_cwd:
        save_file_cwd(wb, Path(f"./saves/{sn}/result/{fn}.xlsx").resolve())
    else:
        save_file_cwd(wb, Path(fn).resolve())
    if GLOBALS[saves_loaded_]:
        print(f"<保存完毕：文件已存储在saves/{GLOBALS[save_name_]}/result目录下>")
    else:
        print("<保存完毕：文件已存储在saves目录下>")


@DisableCondition(not isOpenpyxlExist, _import_error)
def xlsx_gen_main(parent: list, analyzed: list, p: str, need_cwd: bool = False):
    """主要函数"""
    f, m, r = analyzed[0], analyzed[1], analyzed[2]
    father = parent[0][:len(list(r.keys())[0])]
    mother = parent[1][:len(list(r.keys())[0])]
    ws, wb = load()
    ped_data = process(f, m, r)
    write(ped_data, ws, father, mother)
    if need_cwd:
        save_file_cwd(wb, Path(f"./saves/{p}.xlsx").resolve())
    else:
        save_file_cwd(wb, Path(p).resolve())
    if GLOBALS[saves_loaded_]:
        print(f"<保存完毕：文件已存储在saves/{GLOBALS[save_name_]}/result目录下>")
    else:
        print("<保存完毕：文件已存储在saves目录下>")


if isOpenpyxlExist:
    # 如果这个第三方库存在，那么在extensible.py中注册这两个主函数。仅仅适用于有GUI的版本。
    expand(_FORMATS, {"xlsx": [xlsx_gen_from_save_main, xlsx_gen_main]})

if __name__ == '__main__':
    # xlsx_gen_main(
    #     ["Aa", "Aa"],
    #     [{"A": 1, "a": 1}, {"A": 1, "a": 1}, {"AA": 1, "Aa": 2, "aa": 1}],
    #     "./a.xlsx"
    # )
    # xlsx_gen_from_save_main("demo", "./aa.xlsx")
    pass
