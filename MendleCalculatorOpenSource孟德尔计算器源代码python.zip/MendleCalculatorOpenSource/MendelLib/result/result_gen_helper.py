from MStzzfTools.exceptions import LoadError
from MStzzfTools.file_util import loadJsonFile
from MStzzfTools.printer import ms_error


def get_save_info(sn: str) -> (int, str, str, str, str, dict, dict, dict):
    try:
        root = loadJsonFile(f"./saves/{sn}/{sn}.json")[0]
        pool = loadJsonFile(f"./saves/{sn}/gene_pool/parents.json")[0]
    except LoadError:
        ms_error(f"[错误]无法正常读取存档{sn}!")
        raise Exception

    try:
        num, author, credit = root["num"], root["author"], root["credit"]
    except KeyError as e:
        ms_error(f"[错误]加载{sn}时发生错误！")
        pa = ""
        for part in e.args:
            pa += ("[" + part + "]")
        ms_error(f"[错误][./saves/{sn}/{sn}.json]未定义{pa}！")
        raise Exception
    try:
        fa, mo = pool["parent"][0], pool["parent"][1]
        fr, mr, r = pool["parent_peizi"]["father"], pool["parent_peizi"]["mother"], pool["result"]
    except KeyError as e:
        ms_error(f"[错误]加载{sn}时发生错误！")
        pa = ""
        for part in e.args:
            pa += ("[" + part + "]")
        ms_error(f"[错误][./saves/{sn}/{sn}.json]未定义{pa}！")
        raise Exception
    return num, author, credit, fa, mo, fr, mr, r


def write_file(p: str, data: str):
    try:
        with open(p, "x+", encoding="utf-8") as f:
            f.write(data)
            f.flush()
            f.close()
            print(f"[信息][{p}]已被保存！")
    except FileExistsError:
        ms_error(f"[错误]已存在同名文件[{p}]！")
    except Exception as e:
        ms_error(f"[错误]在生成[{p}]时发生意外错误！")
        raise e
