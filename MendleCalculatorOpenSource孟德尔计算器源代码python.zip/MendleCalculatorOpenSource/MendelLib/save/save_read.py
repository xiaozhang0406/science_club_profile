import json
from os import getcwd, path

from MStzzfTools.decorators import BoolControl, _do_this, _pass
from MStzzfTools.file_util import JsonDecodeErrorHelper
from MStzzfTools.printer import *
from MendelLib.mendel_meta import _META, _meta_version


def v_error_helper(r_save_main: dict):
    ms_error("强行加载存档将可能导致存档损坏，是否坚持加载该存档？(1 = '要')")
    if ms_input(">") == '1':
        print_ca(r_save_main)
    else:
        print("<已取消加载存档>")
        raise EOFError


@BoolControl(1, "PrintCreditsWhileReadingSaves", _do_this, _pass)
def print_credit(r_save_main: dict):
    try:
        print("注释[" + r_save_main['credit'] + ']')
    except KeyError:
        ms_warn("<警告：存档配置文件中似乎没有定义[credit]!>")


@BoolControl(1, "PrintAuthorWhileReadingSaves", _do_this, _pass)
def print_author(r_save_main: dict):
    try:
        if r_save_main['author'] is None:
            ms_warn("<警告：存档配置文件中将[AuthorName]定义为null!>")
        else:
            print("作者[" + r_save_main['author'] + ']')
    except KeyError:
        ms_warn("<警告：存档配置文件中似乎没有定义[author]!>")


def print_ca(r_save_main: dict):
    print_author(r_save_main)
    print_credit(r_save_main)


def get_structure(save_name: str):
    r_save_dir = (getcwd() + "\\saves\\" + save_name).replace("\\", "/")
    is_exists = path.exists(r_save_dir)

    # 判断结果
    if not is_exists:
        ms_error("<加载失败：[" + r_save_dir + "]不存在!>")
        return 0
    else:
        print("<正在读取目录[" + r_save_dir + "]...>")

        try:
            r_file = open((r_save_dir + "\\" + save_name + ".json").replace("\\", "/"), 'r')
            r_save_m = r_file.readlines()
            r_file.close()
            r_save_main = ''
            for line in r_save_m:
                r_save_main = r_save_main + line
            r_save_main = json.loads(r_save_main)
        except FileNotFoundError:
            ms_error("<加载失败：存档配置文件[" + r_save_dir + "/" + save_name + ".json]似乎不存在！>")
        except json.decoder.JSONDecodeError as JE:
            JsonDecodeErrorHelper(JE, r_save_dir + "/" + save_name + ".json")

        else:
            try:
                r_loader_v = r_save_main['loader_version']
            except KeyError:
                ms_error("<加载失败：存档配置文件似乎没有定义版本[loader_version]！>")
                v_error_helper(r_save_main)
            else:
                if r_loader_v not in _loader_version:
                    ms_error(f"[错误]此程序不支持版本为{r_loader_v}的存档！")
                    v_error_helper(r_save_main)
                else:
                    print_ca(r_save_main)

                    global _save_main_file, nuum
                    try:
                        nuum = r_save_main["num"]
                    except KeyError:
                        ms_error("<加载失败：存档配置文件似乎没有定义等位基因数[num]！>")
                    _save_main_file = r_save_main


def get_gene_pool(save_name):
    ggp_dir = (getcwd() + "\\saves\\" + save_name + "\\gene_pool\\").replace("\\", "/")
    is_exists = path.exists(ggp_dir + "parents.json")
    r_save_mai = {}

    '''获得第一对亲代的基因和配子'''
    if not is_exists:
        ms_error("<加载失败：[" + save_name + "/parents.json]似乎不存在!>")
        return 0
    else:
        print("<正在读取基因库文件[" + save_name + "/parents.json]...>")

        try:
            r_file = open(ggp_dir + "parents.json", 'r')
            r_save_m = r_file.readlines()
            r_file.close()
            r_save_main = ''
            for line in r_save_m:
                r_save_main = r_save_main + line
            r_save_mai = json.loads(r_save_main)
        except json.decoder.JSONDecodeError as JE:
            JsonDecodeErrorHelper(JE, save_name + "/parents.json")

        '''获得子代们的基因和配子'''
        # TODO：读取此文件夹下的所有基因库文件
        '''
        for root,dirs,files in os.walk(ggp_dir):
            for file in files:
                f.writelines(os.path.join(root,file)+"\n") 

        '''
        global parent_peizi, nuum, _format_suc_load_1, _format_suc_load_2
        try:
            # 会返回一个预先处理过的结果和配子字典来加快处理速度。
            # 这同时也是最初开发存档这一功能的初衷。
            global father, mother, rsm_result
            parent_peizi = r_save_mai["parent_peizi"]
            father = r_save_mai["parent"][0]
            mother = r_save_mai["parent"][1]
            rsm_result = r_save_mai["result"]
            print(_format_suc_load_1.format(save_name + "/gene_pool/parents.json"))
            print(_format_suc_load_2.format(r_save_mai["parent"], nuum).replace("\'", ""))
        except KeyError:
            ms_error("<加载失败：基因库文件中的亲本似乎没有定义[result]、[parent]、[parent_peizi]三者之一!>")
        except TypeError:
            ms_error("<加载失败：%s\parents.json中的[parent_num]似乎不是整数!>" % ggp_dir)
        except IndexError:
            ms_error("<加载失败：基因库文件中的亲本不符合格式要求！!>")


def read_save_main(save_name: str) -> (dict, dict, dict, int, str, str, str):
    try:
        if get_structure(save_name) == 0:
            return {}, {}, {}, 0, '', '', ''
    except EOFError:
        return {}, {}, {}, 0, '', '', ''
    global parent_peizi, nuum, father, mother, rsm_result
    get_gene_pool(save_name)
    fa_peizi = parent_peizi['father']  # 父本配子 dict
    mo_peizi = parent_peizi['mother']  # 母本配子 dict
    return fa_peizi, mo_peizi, rsm_result, nuum, save_name, father, mother


_save_main_file = {}
_format_suc_load_1 = "<已成功载入基因库文件[{}]!>"
_format_suc_load_2 = "<亲本[{}]，等位基因数[{}]>"
parent_peizi, nuum = {}, 0
father = mother = ''
rsm_result = {}

# TODO:将来就要把存档里的那个版本存储格式改掉了。这只是个暂时的方案。
_loader_version = [_META[_meta_version][0] + _META[_meta_version][1] * 0.1, list(_META[_meta_version])]
