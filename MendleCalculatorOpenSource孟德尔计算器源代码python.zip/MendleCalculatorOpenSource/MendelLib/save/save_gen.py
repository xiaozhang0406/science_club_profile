from os import walk
from shutil import copytree, rmtree, copyfile

from MStzzfTools.exceptions import SaveError
from MStzzfTools.file_util import saveJsonFile, makedir
from MStzzfTools.printer import *
from MendelLib.mendel_helper import isIllegalSaveName
from MendelLib.mendel_meta import _META, _saves_dir, _meta_version, _cache_dir
from MendelLib.mendel_settings import setting_dict


def gen_structure(_dir):
    makedir(_dir)
    makedir(_dir + "/gene_pool")
    makedir(_dir + "/result")


def gen_base_file(s_name, s_credit, gene):
    global _save_base_json
    save_base = _cache_dir.joinpath(s_name).joinpath(s_name + ".json").resolve()
    _save_base_json["num"] = int(len(gene) / 2)
    _save_base_json["name"] = s_name
    _save_base_json["credit"] = s_credit
    saveJsonFile(save_base, _save_base_json, "a+", False)


def gen_gene_pool(father: str, mother: str, s_name: str, gene_f: dict, gene_m: dict, r: dict, g_name='parents'):
    global _save_gene_pool
    save_pool = _cache_dir.joinpath(s_name).joinpath("gene_pool").joinpath(g_name + ".json").resolve()
    _save_gene_pool["parent"][0] = father
    _save_gene_pool["parent"][1] = mother
    _save_gene_pool["parent_peizi"]["father"] = gene_f
    _save_gene_pool["parent_peizi"]["mother"] = gene_m
    _save_gene_pool["result"] = r
    saveJsonFile(save_pool, _save_gene_pool, "a+", False)


def mvtree(save_name: str):
    """感觉他们的 copy 和 rm 功能的逻辑是错乱的，
    因为移动时出错了（就是爆红了）才会成功地移动文件夹，
    这一点在 普 通 环 境 中 得到了 证 实 草!!!
    是的，这个问题在3.10当中也没有变化
    """
    from_dir = _cache_dir.joinpath(save_name)
    to_dir = _saves_dir.joinpath(save_name)
    print("复制文件夹：[" + str(from_dir) + "]到[" + str(to_dir) + "]")
    copytree(from_dir, to_dir)

    file_list = []
    for fold, dirs, files in walk(from_dir):
        for file in files:
            file_list.append((fold.replace(str(_cache_dir), "./cache") + file).replace("\\", "/"))

    # print(file_list)
    for f in file_list:
        print("复制文件：[" + f + "]到[" + f.replace("/cache", "/saves") + "]")
        copyfile(f, f.replace("/cache", "/saves"))


'''主函数'''


def gen_save_main(father: str, mother: str, gsm_gene_f: dict, gsm_gene_m: dict, r: dict, save_name: str,
                  save_credit: str):
    if isIllegalSaveName(save_name):
        return 0
    cache_dir = str(_cache_dir.joinpath(save_name))
    try:
        gen_structure(cache_dir)
        gen_base_file(save_name, save_credit, father)
        gen_gene_pool(father, mother, save_name, gsm_gene_f, gsm_gene_m, r)
    except SaveError:
        print(format_exc())
        return 0
    # 此部分靠bug运行！请勿尝试修复它。
    # 如果你要修改，请做好备份！！！！
    try:
        print("[信息]正在移动文件。")
        mvtree(save_name)
    except FileNotFoundError:
        # 奇怪的运行逻辑！！！
        print("[信息]存档生成完毕！")
        rmtree("./cache/" + save_name)
    except :
        ms_error("[错误]无法移动文件夹！")
        print(format_exc())


try:
    author = setting_dict["AuthorName"]
    if author is None:
        ms_warn("[警告]请更新[mendel_settings.json]中的[AuthorName]！")
except KeyError:
    author = "null"
    ms_error("[错误]未在[mendel_settings.json]中定义[AuthorName]")

'''模板'''
_save_base_json = dict({"loader_version": _META[_meta_version],
                        "num": 0,
                        "name": "",
                        "author": author,
                        "credit": ""})

_save_gene_pool = {
    "parent": ["", ""],
    "parent_peizi": {
        "father": {},
        "mother": {}
    },
    "result": {}
}

# TODO:针对父母基因型进行改进
# 当遇见父本是【Aa:0.6, AA:0.4】时，要怎么处理？？
# 把parent改成包含字典的列表， 如   "parent": [{"Aa": 1}, {"Aa": 1}]

if __name__ == '__main__':
    save_name = "5t"
    try:
        mvtree(save_name)
    except FileNotFoundError:
        rmtree("./cache/" + save_name)
