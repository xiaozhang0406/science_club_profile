from threading import Timer
from tkinter.scrolledtext import ScrolledText
from tkinter.ttk import Progressbar
from typing import Dict

from MendelLib.extensible import _mo_presets
from MendelLib.gui.InterfaceBasic import *
from MendelLib.gui.cmd_compact import calcWithWin
from MendelLib.mendel_helper import isIllegalCommand, isIllegalGenes, about_program, about_us, users_cookbook, \
    other_info
from MendelLib.mendel_meta import (GLOBALS, number_, father_, mother_, saves_loaded_, calc_data_,
                                   global_calc_data_upd, is_exit, save_name_)
from MendelLib.result.txt_gen import result_str_maker


class MendelCalcGUI(BasicGUI):
    _button_list: Dict[str, Widget] = {}

    label_info_base = "-" * 30 + "\n信息: "
    label_probar_base = "进度(%s/%s)"
    die_filter = '\\'
    save_name = '\\'

    _thread_msg = ''
    _last_msg = ''

    def __init__(self):
        BasicGUI.__init__(self)
        self.bind("<Escape>", self._quit)   # 将键位绑定到函数上。

    # 设置窗口
    def set_init_window(self):

        self.make_tool_bar()
        # 标签
        self.label_num_input = Label(self, text="等位基因数：")
        self.label_num_input.grid(row=0, column=0)
        self.text_num = Text(self, width=4, height=0)
        self.text_num.insert(INSERT, GLOBALS[number_])
        self.text_num.grid(row=0, column=1)

        self.label_thread_msg = Label(self, text=self._thread_msg, justify=LEFT)
        self.label_thread_msg.grid(row=1, column=0, columnspan=4, sticky=W + N)

        self.label_father = Label(self, text="父本：")
        self.label_father.grid(row=2, column=0, sticky=W + N)
        self.text_fa = Text(self, width=22, height=1)
        self.text_fa.insert(INSERT, GLOBALS[father_])
        self.text_fa.grid(row=3, column=0, columnspan=4, sticky=N)

        self.make_button()

        self.label_mother = Label(self, text="母本：预设:")
        self.label_mother.grid(row=4, column=0, sticky=W + N)
        self.text_mo = Text(self, width=22, height=1)
        self.text_mo.insert(INSERT, GLOBALS[mother_])
        self.text_mo.grid(row=5, column=0, columnspan=4, sticky=N)
        self.need_preset = BooleanVar()     # 一个可以被窗口实时捕获和修改的变量,
        self.checkbox_mo_preset = Checkbutton(self, variable=self.need_preset)
        self.checkbox_mo_preset.grid(row=4, column=1, sticky=W+N)

        self.label_out_put = Label(self, text="输出结果：")
        self.label_out_put.grid(row=0, column=11)
        self.label_filter = Label(self, text="筛选：")
        self.label_filter.grid(row=0, column=12)
        self.label_info = Label(self, text=self.label_info_base, justify=LEFT)
        self.label_info.grid(row=6, column=0, rowspan=10, columnspan=4, sticky=W + N)
        self.label_probar = Label(self, text=self.label_probar_base % (0, 0))
        self.label_probar.grid(row=22, column=0, columnspan=4, sticky=W + N)

        # 文本框
        self.text_result = ScrolledText(self, width=32, height=38)
        self.text_result.grid(row=1, column=10, rowspan=21, columnspan=3, sticky=E + N)

        # 选择列表
        self.cb_preset = Combobox(self, width=8)
        self.cb_preset["value"] = list(_mo_presets.keys())
        self.cb_preset.current(0)
        self.cb_preset.grid(row=4, column=2, columnspan=3, sticky=W + N)
        self.update_ele()

        # 进度条
        self.probar = Progressbar(self, length=450)
        self.probar.grid(row=25, column=0, columnspan=15, sticky=W + N)

    def make_tool_bar(self):
        menuBar = Menu(self)
        self.config(menu=menuBar)

        basicMenu = Menu(menuBar, tearoff=0)
        menuBar.add_cascade(label="基础", menu=basicMenu)
        basicMenu.add_command(label="计算", command=self._calculate)
        basicMenu.add_command(label="保存", command=self._save_save)
        basicMenu.add_command(label="读取", command=self._read_save)
        basicMenu.add_command(label="导出结果", command=self._result_output)
        basicMenu.add_separator()
        basicMenu.add_command(label="加载预设", command=self._load_preset)
        basicMenu.add_separator()
        basicMenu.add_command(label="退出(Esc)", command=self._quit)

        saveMenu = Menu(menuBar, tearoff=0)
        menuBar.add_cascade(label="存档", menu=saveMenu)
        saveMenu.add_command(label="保存", command=self._save_save)
        saveMenu.add_command(label="读取", command=self._read_save)
        saveMenu.add_command(label="删除", command=self._del_save)
        saveMenu.add_separator()
        saveMenu.add_command(label="导入", command=self._todo)
        saveMenu.add_command(label="导出存档", command=self._todo)
        saveMenu.add_command(label="导出结果", command=self._result_output)
        saveMenu.add_separator()
        saveMenu.add_command(label="存储位置", command=self._show_path)

        cfgMenu = Menu(menuBar, tearoff=0)
        menuBar.add_cascade(label="设置", menu=cfgMenu)
        cfgMenu.add_command(label="外观设置", command=self._todo)
        cfgMenu.add_command(label="功能设置", command=self._todo)
        cfgMenu.add_command(label="其他设置", command=self._todo)
        cfgMenu.add_separator()
        cfgMenu.add_command(label="导入设置", command=self._todo)
        cfgMenu.add_command(label="导出设置", command=self._todo)

        advMenu = Menu(menuBar, tearoff=0)
        menuBar.add_cascade(label="高级", menu=advMenu)
        advMenu.add_command(label="命令行模式", command=self._todo)
        advMenu.add_command(label="插件", command=self._todo)
        advMenu.add_command(label="编辑配置文件", command=self._todo)
        advMenu.add_command(label="日志", command=self._todo)
        advMenu.add_command(label="调试模式", command=self._todo)

        helpMenu = Menu(menuBar, tearoff=0)
        menuBar.add_cascade(label="帮助", menu=helpMenu)
        helpMenu.add_command(label="关于此程序", command=about_program)
        helpMenu.add_command(label="关于我们", command=about_us)
        helpMenu.add_separator()
        helpMenu.add_command(label="使用说明", command=users_cookbook)
        helpMenu.add_command(label="其他信息", command=other_info)

    def make_button(self):
        # 按钮
        optl = {"刷新": [self.update_ele,
                         {"text": "刷新", "width": 10, "height": 1},
                         {"row": 0, "column": 2}],
                "计算": [self._calculate,
                         {"text": "计算", "width": 30, "height": 1},
                         {"row": 22, "column": 11, "columnspan": 2, "sticky": S}]}

        for k in optl:
            # ** 是参数解析运算符，func(**{"row": 0, "column": 2}) 等价于 func(row=0, column=2)
            self._button_list[k] = Button(self, command=optl[k][0], **optl[k][1])
            self._button_list[k].grid(**optl[k][2])

    def get_genes(self):
        GLOBALS[number_] = self.text_num.get(1.0, END).replace("\n", "")
        GLOBALS[father_] = self.text_fa.get(1.0, END).replace("\n", "")
        GLOBALS[mother_] = self.text_mo.get(1.0, END).replace("\n", "")

    # 按钮对应的命令##################################################################################
    def update_ele(self):
        """对所有动态元素进行更新"""
        self.get_genes()
        if not isIllegalCommand(str(GLOBALS[number_])):
            GLOBALS[number_] = int(GLOBALS[number_])
            try:
                preset = _mo_presets[self.cb_preset.get()]
            except KeyError as e:
                preset = _mo_presets["从存档加载"]
                showerror("[错误]无法为母本加载预设！", "[错误]未知的预设名称[ %s ]!" % e.args)
            if self.need_preset.get():
                self.text_mo.delete(1.0, END)
                self.text_mo.insert(INSERT, preset(GLOBALS[father_], GLOBALS[mother_]))
                self.last_mocb = preset
            self.get_genes()
            label_str = self.label_info_base + \
                        "\n存档：" + self.limit_str(GLOBALS[save_name_]) + \
                        "\n死亡筛选：" + self.limit_str(str(self.die_filter)) + \
                        "\n等位基因数：" + str(GLOBALS[number_]) + \
                        "\n父本：" + self.limit_str(GLOBALS[father_]) + \
                        "\n母本：" + self.limit_str(GLOBALS[mother_])
            self.label_info.config(text=label_str)

    @staticmethod
    def limit_str(s: str):
        return s[:14] + "..." if len(s) > 16 else s

    def _check_entry(self, EchoOn=True):
        self.update_ele()
        result = isIllegalGenes(int(GLOBALS[number_]), GLOBALS[father_], GLOBALS[mother_], silent=True)
        return not result

    def _calculate(self):
        if GLOBALS[saves_loaded_]:
            self.text_result.delete(1.0, END)
            self.text_result.insert(INSERT, "从存档加载：" + result_str_maker(GLOBALS[calc_data_]))
        else:
            if self._check_entry(EchoOn=False):
                if self.isCalculating:
                    showerror("[警告]正在进行计算！", "[警告]您当前正在进行一个计算！请等待计算结束后再进行其他计算！")
                    return
                self.probar['value'] = 0
                self.isCalculating = True
                GLOBALS[calc_data_], t = calcWithWin(int(GLOBALS[number_]), GLOBALS[father_], GLOBALS[mother_], self)
                global_calc_data_upd()
                self.text_result.delete(1.0, END)
                self.text_result.insert(INSERT, result_str_maker(GLOBALS[calc_data_]) + t)
                self.isCalculated = True
                self.isCalculating = False

    # 菜单中的命令##################################################################################
    def _todo(self):
        showerror(
            "[错误]此版本程序暂不支持此功能！",
            "[错误]我们还未为这个程序编写此功能！你可以前往[https://gitee.com/meteorshower2004/MendelCalculatorDOC/releases]检查是否有最新版本！"
        )

    def _read_save(self):
        dialog = IReadSave(self)
        self.wait_window(dialog)
        if not dialog.cancel and GLOBALS[save_name_] != "\\":
            GLOBALS[saves_loaded_] = True
            self.isCalculated = True
        return

    def _save_save(self):
        if self.isCalculated or GLOBALS[saves_loaded_] or GLOBALS[save_name_] != "\\":
            dialog = ISaveGen_make(self)
            self.wait_window(dialog)
            if not dialog.cancel:
                GLOBALS[saves_loaded_] = True
        else:
            showerror("[错误]无法保存存档！", "[错误]请先进行计算或者读取，再保存存档！")
        return

    def _del_save(self):

        dialog = IDelSave(self)
        self.wait_window(dialog)    #通过wait()函数来达成等待小窗口相应和防止“无响应”的目的。
        return

    def _load_preset(self):
        dialog = ILoadPreset(self)
        self.wait_window(dialog)
        return

    def _result_output(self):
        if GLOBALS[saves_loaded_] or self.isCalculated:
            dialog = IResultOutput(self)
            self.wait_window(dialog)
        else:
            showerror("[错误]无法输出结果！", "[错误]请先进行计算或者读取，再保存结果！")
        return

    def _show_path(self):
        dialog = ISavePath(self)
        self.wait_window(dialog)
        return


class LogicThread(Timer):
    """一个还不太稳定的逻辑处理线程。
    负责自动更新窗口数据和启动时检查更新。
    注意！这个线程在程序崩溃或强制停止的时候仍然可能会运行，所以需要手动关闭，否则就成了僵尸线程。
    """

    def __init__(self, gui: MendelCalcGUI):
        # 频率是0.5s一次。
        Timer.__init__(self, 0.5, None)
        self.setName("[LogicHandlerThread]")
        self._gui = gui
        self.last_father = ' '
        self.last_mother = ' '
        self.last_num = ' '

    def run(self):
        from MendelLib.mendel_helper import check_upd
        check_upd()

        # self.finished的相关代码请参见threading.Timer类
        while not self.finished.is_set():
            if is_exit() or self._gui.state() != "normal":
                break

            if not self._gui.is_cleaning:
                self._gui.get_genes()
                father, mother, num = GLOBALS[father_], GLOBALS[mother_], GLOBALS[number_]
                if str(GLOBALS[number_]) == '':
                    self.set_msg("输入内容检查:\n" + self.limit_str("[错误]输入不能为空！"))
                    continue
                if isIllegalCommand(str(GLOBALS[number_]), silent=True):
                    self.set_msg("输入内容检查:\n" + self.limit_str("[错误]请输入一个一位自然数！"))
                    continue
                if self.last_father != father or self.last_mother != mother or self.last_num != num:
                    r = isIllegalGenes(num, father, mother, True, True)
                    thread_msg = '√' if not r[0] else r[1]
                    self.set_msg("输入内容检查:\n" + self.limit_str(thread_msg))

            self.finished.wait(self.interval)

    def set_msg(self, s):
        self._gui.label_thread_msg.config(text=s)

    @staticmethod
    def limit_str(s):
        l = 10
        if len(s) <= l:
            return s
        st = []
        for i in range(l, len(s) + 1, l):
            st.append(s[i - l:i])
        if len(s) % l != 0:
            st.append(s[-(len(s) % l):])
        # else:
        #     st.append(s[(len(s)//l-1)*l:])
        return "\n".join(st)
