"""兼容层，
让计算进度可视化，同时防止主程序窗口“无响应”
我们在MendelLib/mendel_console.py中对函数进行了处理，增加了callback(回调函数)，这样函数的可复用性就提高了，
可视化计算进度的时候，我们写一点callback实例塞进去就好了。多方便！
"""
from time import time_ns
from typing import Tuple

from MStzzfTools.mtype_util import CBIteration
import MendelLib.extensible as ext
# 有一种注册方法就是通过import来直接修改，不使用from是因为from返回的是一个拷贝，
# 浅拷贝，所以修改拷贝不会对原变量产生影响。但有一些复制不是浅拷贝，这个要自己去探究了
from MendelLib.gui.BasicMendel import BasicGUI
from MendelLib.mendel_console import analyzeChessboard, analyzeChessboard9
from MendelLib.mendel_helper import (recursion_gamete, get_alpha_ignore_case, Callbacks)
from MendelLib.mendel_meta import GLOBALS, gui_
from MendelLib.save.save_gen import gen_save_main


class PresetMaker:
    """母本的预设转化为基因"""

    @staticmethod
    def father(f: str, m: str):
        """等同于父本"""
        return f

    @staticmethod
    def from_saves(f: str, m: str):
        """加载存档时使用！相当于等同于母本"""
        return m

    @staticmethod
    def AA(f: str, m: str):
        """全部显性"""
        return f.upper()

    @staticmethod
    def aa(f: str, m: str):
        """全部隐性"""
        return f.lower()

    @staticmethod
    def Aa(f: str, m: str):
        """全部杂合"""
        gene = ''
        symbol = get_alpha_ignore_case(f)

        for l in symbol:
            gene += l.upper() + l

        return gene

# 注册
ext._mo_presets.update({"等同父本": PresetMaker.father,
               "全部显性": PresetMaker.AA,
               "全部隐性": PresetMaker.aa,
               "全部杂合": PresetMaker.Aa,
               "从存档加载": PresetMaker.from_saves})


def getwin():
    """从GLOBALS获取GUI的实例"""
    if GLOBALS[gui_] is not None:
        return GLOBALS[gui_]
    else:
        raise RuntimeError("[ERROR]Fail to get window instance!")


# CALLBACKS 回调函数和实例 #################################################
# l2d = ListToDict
def l2d_onstart(_list, _set, _dict):
    w = getwin()
    w.probar.config(mode="determinate")
    w.probar["value"] = 0
    w.probar["maximum"] = len(_set)
    w.label_probar.config(text=w.label_probar_base % (0, len(_set)))
    w.update()


def l2d_foreach(index, eum, _list, _set, _dict):
    w = getwin()
    w.probar["value"] += 1
    w.label_probar.config(text=w.label_probar_base % (index + 1, w.probar["maximum"]))
    w.update()


cb_l2d_win = CBIteration(l2d_onstart, l2d_foreach)

# ach = analyzeChessboard
def ach9_on_match():
    w = getwin()
    w.label_probar.config(text="正在处理数据...请稍等。")
    w.update()


def ach9_onstart(_dict):
    w = getwin()
    w.probar.config(mode="determinate")
    w.probar["value"] = 0
    w.probar["maximum"] = len(list(_dict.keys()))
    w.label_probar.config(text=w.label_probar_base % (0, len(_dict)))
    w.update()


def ach9_foreach(index, key):
    w = getwin()
    w.probar["value"] += 1
    w.label_probar.config(text=w.label_probar_base % (w.probar["value"], w.probar["maximum"]))
    w.update()

# cb = callback
cb_analyze_chess_board = Callbacks.AnalyzeChb(cb_l2d_win, ach9_on_match, cb_l2d_win,
                                              CBIteration(ach9_onstart, ach9_foreach))

# 兼容 GUI ########################################
# 本质上和mendel_cmd_pack.calculate()一样。

def calcWithWin(num: int, father: str, mother: str, w: BasicGUI) -> (tuple, str):
    _d1 = time_ns()

    if num < 9:
        feed_back = analyzeChessboard(
            recursion_gamete(father, num),
            recursion_gamete(mother, num),
            callbacks=cb_analyze_chess_board
        )
    # elif num == 9:
    else:
        fp1718 = father[16:]
        mp1718 = mother[16:]
        father = father[:16]
        mother = mother[:16]
        feed_back = analyzeChessboard9(
            recursion_gamete(father, 8), recursion_gamete(mother, 8),
            fp1718, mp1718, callbacks=cb_analyze_chess_board
        )

    _d2 = time_ns()
    dt = round((_d2 - _d1) / 1000000, 3)
    if dt > 10000:
        info = "\n[信息]输出完毕，共使用%s秒！" % str(round(dt / 1000, 2))
    else:
        info = "\n[信息]输出完毕，共使用%s毫秒！" % str(dt)

    print(info)

    return feed_back, info


# 这么写其实没必要。早晚有一天把它删了。
def gen_save(genes: Tuple[str, str], gametes: Tuple[dict, dict], r_dict: dict, save_name: str, save_credit: str):
    """
    genes -> (father: str, mother: str)
    gametes -> (f_list: dict, m_list: dict)
    """
    gen_save_main(genes[0], genes[1], gametes[0], gametes[1], r_dict, save_name, save_credit)


if __name__ == '__main__':
    pass
