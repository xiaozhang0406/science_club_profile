"""用于创建小窗口的抽象类
这里的内容，主要体现了类的继承和多态思想。这样的思想会让你在编程时，思路更清楚，代码量更少。
这里的小窗口主要是从程序的主窗口延伸的（注意小窗口的类不再是Tk而是Toplevel），小窗口通过直接访问主窗口来达到修改主窗口的内容的目的。
可以看看MendelLib/gui/InterfaceBasic.py的IReadSave(WinCombobox)类似怎么实现的。
主窗口通过wait()函数来达成等待小窗口相应和防止“无响应”的目的。
"""

from tkinter import *
from tkinter.filedialog import askdirectory
from tkinter.ttk import Combobox

from MendelLib.gui.BasicMendel import BasicGUI
from MendelLib.mendel_meta import min_geo_top1, max_geo_top1, _ico


class WindowAbstract(Toplevel):
    """最基本的"""
    title_str = "WindowAbstract"
    label_str = 'WindowAbstract: '
    cancel = False

    def __init__(self, parent: BasicGUI):
        Toplevel.__init__(self)
        self.title(self.title_str)
        self.iconbitmap(_ico)
        self.geometry(min_geo_top1.get_win_center(parent).tk_geometry)
        self.minsize(*min_geo_top1.size)
        self.maxsize(*max_geo_top1.size)
        self.parent = parent
        self.make_label()
        self.make_button()
        self.make_spec()
        self.make_others()

    def make_button(self):
        Button(self, text="<-", width=16, height=1, command=self._quit).grid(row=20, column=0, columnspan=4,
                                                                             sticky=E + S)
        Button(self, text="->", width=16, height=1, command=self.next).grid(row=20, column=5, columnspan=4,
                                                                            sticky=E + S)

    def make_label(self):
        Label(self, text=self.label_str).grid(row=0, column=0, sticky=W + N)

    def _quit(self):
        """结束主事件循环"""
        self.cancel = True
        self.destroy()

    def make_others(self):
        """用于第三级继承"""
        pass

    def make_spec(self):
        """用于第二级继承"""
        pass

    def next(self):
        """点击->按钮时执行的动作"""
        '''# 显式地更改父窗口参数
        self.parent.name = self.name.get()
        self.parent.age = self.age.get()
        # 显式地更新父窗口界面
        self.parent.l1.config(text=self.parent.name)
        self.parent.l2.config(text=self.parent.age)
        self.destroy()  # 销毁窗口'''
        return


class WinCombobox(WindowAbstract):
    """带有下拉列表的小窗口"""
    title_str = "WinCombobox"
    label_str = 'WinCombobox: '
    value_list = ["test"]

    def __init__(self, parent: BasicGUI):
        WindowAbstract.__init__(self, parent)

    def make_spec(self):
        self.cb = Combobox(self, width=12)
        self.cb["value"] = self.value_list
        self.cb.current(0)
        self.cb.grid(row=1, column=0, columnspan=6)


class WinTextInfo(WindowAbstract):
    """带有大文本框的小窗口，通常用来显示文本信息"""
    title_str = "WinText"
    label_str = 'WinText: '
    label_init_value = "Hey! look here! "

    def __init__(self, parent: BasicGUI):
        WindowAbstract.__init__(self, parent)

    def make_spec(self):
        self.text = Text(self, width=34, heigh=20)
        self.text.grid(row=1, column=0, columnspan=10)
        self.set_text_value(self.label_init_value)

    def set_text_value(self, string: str):
        self.text.delete(1.0, END)
        self.text.insert(INSERT, string)


class WinTextInput(WindowAbstract):
    """带有小文本框的小窗口，通常用来输入"""
    title_str = "WinText"
    label_str = 'WinText: '
    label_init_value = "Hey! look here! "

    def __init__(self, parent: BasicGUI):
        WindowAbstract.__init__(self, parent)

    def make_spec(self):
        self.text = Text(self, width=34, heigh=1)
        self.text.grid(row=1, column=0, columnspan=10)
        self.set_text_value(self.label_init_value)

    def set_text_value(self, string: str):
        self.text.delete(1.0, END)
        self.text.insert(INSERT, string)


class WinFileBrowser(WindowAbstract):
    """带有文本框的小窗口"""
    title_str = "WinFileBrowser"
    label_str = 'WinFileBrowser: '
    label_init_value = "选择文件:"

    def __init__(self, parent: BasicGUI):
        """继承的时候一定要记得在init之前确定init_path！！"""
        # 我们默认把文件浏览器的路径设置成程序所在的文件夹下
        # self.init_path = split(__file__)[0].replace("\\", "/").replace("/MendelLib/gui", "")
        WindowAbstract.__init__(self, parent)

    def make_spec(self):
        Label(self, text=self.label_init_value).grid(row=1, column=0, sticky=W + N)
        self.text = Text(self, width=28, heigh=2)
        self.text.grid(row=2, column=0, columnspan=8)
        self.set_text_value(self.init_path)
        self.button_browser = Button(self, text=" ... ", command=self.file_browser)
        self.button_browser.grid(row=2, column=8, columnspan=2, sticky=W)

    def set_text_value(self, string: str):
        self.text.delete(1.0, END)
        self.text.insert(INSERT, string)

    def get_text_value(self):
        self.directroy = self.text.get(1.0, END).replace("\n", "")

    def file_browser(self):
        """导入文件
        askdirectory -> 一个文件夹
        askopenfilename -> 一个文件
        askopenfilenames -> 多个文件
        """
        self.directroy = askdirectory(title=self.title_str, initialdir=self.init_path)
        self.set_text_value(self.directroy)


if __name__ == '__main__':
    pass
    # root = Tk()
    #
    # WinTextInfo(Tk()).mainloop()
    # WindowAbstract(Tk()).mainloop()
    # WinCombobox(Tk()).mainloop()
    # WinTextInput(Tk()).mainloop()
    # WinFileBrowser(Tk()).mainloop()
