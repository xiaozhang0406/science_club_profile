"""大多数继承自WindowsAbstract
这里的内容，主要体现了类的继承和多态思想。这样的思想会让你在编程时，思路更清楚，代码量更少。
"""
from os import chdir, remove
from os.path import exists
from pathlib import Path
from shutil import rmtree
from time import strftime, localtime
from tkinter.messagebox import showerror, showinfo, askquestion, askyesno
from traceback import format_exc

from MStzzfTools.file_util import get_dir
from MStzzfTools.tk import set_value, get_value, set_text_value
from MendelLib.extensible import _formats, _preset_genes
from MendelLib.gui.WindowAbstract import *
from MendelLib.gui.cmd_compact import gen_save
from MendelLib.mendel_helper import isIllegalSaveName
from MendelLib.mendel_meta import (GLOBALS, number_, father_, mother_, saves_loaded_, save_name_,
                                   calc_data_, f_, m_, r_, global_calc_data_create, upd_saves, )
from MendelLib.mendel_meta import _saves_dir, _saves
from MendelLib.result.txt_gen import result_str_maker
from MendelLib.save.save_read import read_save_main


class IReadSave(WinCombobox):
    title_str = "读取存档"
    label_str = '读取存档名字: '

    def __init__(self, parent: BasicGUI):
        WinCombobox.__init__(self, parent)
        self.make_cb_values()
        self.cb.config(width=31)

    def make_others(self):
        # TODO: 需要完善！！！！
        Checkbutton(self, text="同时读取死亡筛选器(未完成)").grid(row=3, column=0, columnspan=10)

    def make_cb_values(self):
        upd_saves()
        self.cb["value"] = _saves
        self.cb.current(0)

    def next(self):
        save_name = self.cb.get()
        try:
            f, m, r, num, save_name, father, mother = read_save_main(save_name)
        except EOFError:
            pass
        else:
            set_text_value(self.parent.text_num, str(num))
            set_text_value(self.parent.text_fa, father)
            set_text_value(self.parent.text_mo, mother)
            set_text_value(self.parent.text_result, "从存档加载：" + result_str_maker((f, m, r)))
            GLOBALS[save_name_] = save_name
            global_calc_data_create((f, m, r))
            self.parent.cb_preset.current(4)
            self.parent.update_ele()
            self.parent.isCalculated = self.parent.isSaveRead = True
            self.destroy()


class ISaveGen_make(WinTextInput):
    title_str = "保存存档"
    label_str = '存档名字: '

    def __init__(self, parent: BasicGUI):
        self.label_init_value = "%s-%s" % (GLOBALS[father_], GLOBALS[mother_])
        WinTextInput.__init__(self, parent)

    def make_others(self):
        Label(self, text="作者(暂不支持)：").grid(row=3, column=0, sticky=W + N)
        self.cb_author = Combobox(self, width=31)
        self.cb_author["value"] = ["authors!"]
        self.cb_author.current(0)
        self.cb_author.grid(row=4, column=0, columnspan=10)
        Label(self, text="注释：").grid(row=5, column=0, sticky=W + N)
        self.text_credit = Text(self, width=34, height=13)
        self.text_credit.grid(row=6, column=0, columnspan=10)

    def next(self):
        self.save_name = self.text.get(1.0, END).replace("\n", "")
        if self.save_name in get_dir(_saves_dir):
            showerror("[错误]无法保存存档！", "[错误]已经有同名的存档存在！")
            return
        self.author = self.cb_author.get().replace("\n", "")
        self.credit = self.text_credit.get(1.0, END).replace("\n", "")
        Ic = ISaveGen_check(self.parent, self.save_name, self.author, self.credit)
        self.wait_window(Ic)
        if Ic.cancel:
            return
        self.destroy()


class ISaveGen_check(WinTextInfo):
    title_str = "保存存档-确认信息"
    label_str = '信息'

    def __init__(self, parent: BasicGUI, save_name, author, credit):
        self.save_name = save_name
        self.author = author
        self.credit = credit
        self.label_init_value = "存档名：%s\n作者：%s\n父本：%s\n母本：%s\n注释：%s\n" % \
                                (self.save_name, self.author, GLOBALS[father_], GLOBALS[mother_], self.credit)
        WinTextInfo.__init__(self, parent)

    def next(self):
        gen_save((GLOBALS[father_], GLOBALS[mother_]),
                 (GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_]),
                 GLOBALS[calc_data_][r_],
                 self.save_name, self.credit)

        self.destroy()


class IDelSave(WinCombobox):
    title_str = "删除存档"
    label_str = '删除存档名字: '

    def __init__(self, parent: BasicGUI):
        WinCombobox.__init__(self, parent)
        self.make_cb_values()
        self.cb.config(width=31)

    def make_cb_values(self):
        self.cb["value"] = get_dir(_saves_dir)
        self.cb.current(0)

    def set_text_value(self, text: Text, s: str):
        text.delete(1.0, END)
        text.insert(INSERT, s)

    def next(self):
        s_name = self.cb.get()
        if askquestion("[警告]确定要删除这个存档吗？",
                       "[警告]确定要删除[%s]吗？一旦删除此存档将不可能再次恢复！！" % s_name) == "yes":
            try:
                # print((getcwd() + '\\saves\\').replace("\\", "/")+s_name+"/")
                p = Path(_saves_dir).joinpath(s_name)
                if p.is_dir():
                    rmtree(p)
                else:
                    remove(p)
            except:
                showerror("[错误]无法删除存档/文件！", ("[错误]无法删除[%s]！错误细节如下：\n" % s_name) + format_exc())
            else:
                showinfo("[信息]成功删除存档/文件", "[信息]已成功删除存档[%s]！" % s_name)
            self.destroy()


class ILoadPreset(WinCombobox):
    title_str = "读取存档"
    label_str = '读取存档名字: '

    def __init__(self, parent: BasicGUI):
        WinCombobox.__init__(self, parent)
        self.make_cb_values()

    def make_others(self):
        Button(self, text="刷新以查看注释", command=self._update).grid(row=1, column=3, columnspan=8)
        self.label = Label(self, text='注释：\\', justify=LEFT, wraplength=220)
        self.label.grid(row=4, column=0, columnspan=10)

    def make_cb_values(self):
        self.cb["value"] = list(_preset_genes.keys())
        self.cb.current(0)

    def set_text_value(self, text: Text, s: str):
        text.delete(1.0, END)
        text.insert(INSERT, s)

    def _update(self):
        self.label.config(text="注释：%s" % self.get_preset()[3])

    def get_preset(self):
        try:
            preset = _preset_genes[self.cb.get()]
        except KeyError as e:
            showerror("[错误]无法加载此预设！", "[错误]未知的预设名称[ %s ]!" % e.args)
            return _preset_genes["演示"]
        else:
            return preset

    def next(self):
        preset = self.get_preset()
        num, father, mother = preset[0], preset[1], preset[2]
        self.set_text_value(self.parent.text_num, str(num))
        self.set_text_value(self.parent.text_fa, father)
        self.set_text_value(self.parent.text_mo, mother)
        GLOBALS[save_name_] = "\\"
        GLOBALS[saves_loaded_] = False
        self.parent.cb_preset.current(4)
        self.parent.update_ele()
        self.destroy()


class IResultOutput(WinFileBrowser):
    """导出结果"""
    title_str = "导出结果"
    label_str = '导出存档: '
    label_init_value = "目标:"

    def __init__(self, parent: BasicGUI):
        self.parent = parent
        self.shouldIncludeNow = (not self.parent.isCalculating) and (
                GLOBALS[saves_loaded_] or self.parent.isCalculated or GLOBALS[save_name_] != "\\")
        self.init_path = _saves_dir
        if self.shouldIncludeNow:
            self.targets = ["当前计算结果"] + _saves
            self.init_file_name = self.result_name()
        else:
            self.init_path += _saves[0] + "/result/"
            self.targets = _saves
            self.init_file_name = f"result-{_saves[0]}"
        WinFileBrowser.__init__(self, parent)
        self.text.grid(row=4, column=0)
        self.button_browser.grid(row=4, column=8, columnspan=2, sticky=W)

    def make_others(self):
        Button(self, text="刷新", width=6, command=self.update_ele).grid(row=2, column=7, columnspan=3)
        self.cb_target = Combobox(self, width=24)
        self.cb_target.grid(row=2, column=0, columnspan=7)
        self.cb_target["value"] = self.targets
        self.cb_target.current(0)

        Label(self, text="选择保存路径：", justify=LEFT).grid(row=3, column=0)

        Label(self, text="格式：", justify=LEFT).grid(row=5, column=0)
        self.cb_f = Combobox(self, width=30)
        self.cb_f.grid(row=6, column=0, columnspan=10)
        self.cb_f["value"] = list(_formats.keys())
        self.cb_f.current(0)

        Label(self, text="名称：", justify=LEFT).grid(row=7, column=0)
        self.text_name = Text(self, width=32, height=1)
        self.text_name.grid(row=8, column=0, columnspan=10)
        set_value(self.text_name, self.init_file_name)

        self.last_text = get_value(self.text)
        self.last_text_name = get_value(self.text_name)
        self.last_cb_target = self.cb_target.get()

    def update_ele(self):
        if self.cb_target.get() != self.last_cb_target:
            if not (self.cb_target.get() in _saves and self.last_cb_target in _saves):
                if self.cb_target.get() in _saves:
                    self.refresh_path(self.result_dir_save())
                    self.refresh_name(self.result_name_save())
                else:
                    self.refresh_path(_saves_dir)
                    self.refresh_name(self.result_name())
            else:
                if self.cb_target.get() in _saves:
                    self.refresh_path(self.result_dir_save())
                    self.refresh_name(self.result_name_save())
                else:
                    self.refresh_path(_saves_dir)
                    self.refresh_name(self.result_name())
            self.last_cb_target = self.cb_target.get()

        if get_value(self.text) != self.last_text:
            if self.is_legal_path(get_value(self.text)):
                self.last_text = get_value(self.text)
            else:
                set_value(self.text, self.last_text)

        if get_value(self.text_name) != self.last_text_name:
            r = isIllegalSaveName(get_value(self.text_name), True)
            showerror("[错误]文件名不合格！", r[1])
            if r[0]:
                self.last_text_name = get_value(self.text_name)
            else:
                set_value(self.text_name, self.last_text_name)

    def is_legal_path(self, p: str):
        if not exists(p):
            showerror("[错误]不合格的路径！", "[错误]这个路径不合格，可能的原因：此路径不存在")
            return False
        return True

    def result_name(self):
        return f"r{strftime('%m-%d-%H-%M', localtime())}-{GLOBALS[father_]}-{GLOBALS[mother_]}"

    def result_name_save(self):
        return f"result-{self.cb_target.get()}"

    def result_dir_save(self):
        return _saves_dir.joinpath(self.cb_target.get()).joinpath("result")

    def refresh_path(self, p: str):
        v = get_value(self.text)
        isNotOfficialPart = v not in [_saves_dir, _saves_dir.joinpath(self.last_cb_target).joinpath("result")]
        notTheSame = (p != v)

        if self.is_legal_path(v) and isNotOfficialPart and notTheSame:
            if askyesno("是否要替换[保存路径]？", f"是否要将[保存路径]从{v}替换为{p}"):
                self.last_text = v
                set_value(self.text, p)
        else:
            self.last_text = v
            set_value(self.text, p)

    def refresh_name(self, n: str):
        v = get_value(self.text_name)
        isNotOfficialPart = v not in [f"result-{self.last_cb_target}",
                                      f"r{strftime('%m-%d-%H-%M', localtime())}-{GLOBALS[father_]}-{GLOBALS[mother_]}"]
        notTheSame = (n != v)

        if isIllegalSaveName(v) and isNotOfficialPart and notTheSame:
            if askyesno("是否要替换[文件名称]？", f"是否要将[文件名称]从{v}替换为{n}"):
                self.last_text_name = v
                set_value(self.text_name, n)
        else:
            self.last_text_name = v
            set_value(self.text_name, n)

    def next(self):
        self.update_ele()
        self.directroy = str(Path(get_value(self.text)).joinpath(get_value(self.text_name) + "." + self.cb_f.get()).resolve())
        r_dir = self.directroy
        print(self.directroy)
        try:
            f = self.cb_f.get()
            if self.cb_target.get() in _saves:
                # 如果要导出存档当中的内容，那么就用针对存档的方法。
                _formats[f][0](self.cb_target.get(), self.directroy)
            else:
                _formats[f][1]([GLOBALS[father_], GLOBALS[mother_]],
                               [GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_], GLOBALS[calc_data_][r_]],
                               self.directroy)
        except:
            showerror("[错误]生成文件失败！", f"[信息]无法将结果导出至[{r_dir}]！\n详细信息：\n{format_exc()}")
        else:
            showinfo("[信息]成功生成文件！", f"[信息]成功将结果导出至[{r_dir}]！")
        self.destroy()


class ISavePath(WinTextInfo):
    title_str = "存储位置"
    label_str = '存储位置：\n此处的修改将不会生效'

    def __init__(self, parent: BasicGUI):
        self.label_init_value = _saves_dir
        WinTextInfo.__init__(self, parent)
        self.text.config(width=34, heigh=18)


if __name__ == '__main__':
    chdir(Path(__file__).resolve().parent.parent.parent)
    from MendelLib.gui.cmd_compact import calcWithWin

    root = BasicGUI()
    GLOBALS[calc_data_] = calcWithWin(int(GLOBALS[number_]), GLOBALS[father_], GLOBALS[mother_], root)[0]
    IResultOutput(root).mainloop()
