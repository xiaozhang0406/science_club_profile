"""程序主窗口的基本类。具体实现在MendelLib/gui/gui.py中"""

from tkinter import *
from tkinter.messagebox import askquestion
from tkinter.ttk import Combobox

from MendelLib.mendel_meta import _title, _ico, _geo, min_geo, max_geo, set_exit


class BasicGUI(Tk):
    _button_list = {}
    last_mocb = ''

    result_list = []

    label_info_base = ""
    label_probar_base = ""
    label_probar = ""

    isCalculated = False
    isCalculating = False
    is_cleaning = False

    def __init__(self):
        Tk.__init__(self)
        self.title(_title)
        self.geometry(_geo.get_center(self.winfo_screenwidth(), self.winfo_screenheight()).tk_geometry)
        self.iconbitmap(_ico)
        # * 是参数解析运算符，func(*[0, 2]) 等价于 func(0, 2)
        self.minsize(*min_geo.size)
        self.maxsize(*max_geo.size)
        self.text_fa = Text(self)
        self.text_mo = Text(self)
        self.text_num = Text(self)
        self.text_result = Text(self)
        self.cb_preset = Combobox(self)
        self.focus_force()

    def set_init_window(self):
        pass

    def update_ele(self):
        pass

    # 按钮对应的命令##################################################################################
    def _quit(self, event=None):
        """结束主事件循环"""
        if self.isCalculating:
            if askquestion("[警告]正在进行计算！",
                           "[警告]程序正在进行计算，退出将会导致计算结果完全丢失，是否要退出？") == "yes":
                self.quit()
                self.destroy()
                set_exit()
                exit()
        else:
            self.quit()
            self.destroy()
            set_exit()
            exit()
