"""提供设置的读取和控制
出现时间早于2021-8-15
很混乱，不建议参考
"""
from os import chdir

from MStzzfTools.file_util import *

def GetSettings():
    global setting_dict
    fs = ''
    try:
        with open((getcwd() + '\\mendel_settings.json').replace("\\", "/"), 'r', encoding="utf-8") as f:
            for stri in f.readlines():
                fs += stri
            setting_dict = json.loads(fs)
            f.close()
    except FileNotFoundError:
        noFileHelper("/settings.json", 'imp')
    except json.decoder.JSONDecodeError as JE:
        LostSthHelper("settings.json", 'imp', JE)
    else:
        return setting_dict


chdir(Path(__file__).resolve().parent.parent)
setting_dict = GetSettings()

_default = {
    "AuthorName": None,

    "PromoteCmdIfIllegalTyping": True,
    "PrintCreditsWhileReadingSaves": True,
    "PrintAuthorWhileReadingSaves": True,
    "PrintCreditsWhileDieFilter": True,

    "AutoCheckUpdate": True
}
