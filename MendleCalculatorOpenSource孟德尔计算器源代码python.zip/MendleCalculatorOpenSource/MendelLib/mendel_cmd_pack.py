"""包装函数"""
from os import system
from platform import system as psys
from traceback import print_exc

from MendelLib.mendel_console import analyzeChessboard9, analyzeChessboard, result_printer
from MendelLib.mendel_helper import recursion_gamete, printFiles, AboutProgram, AboutUs, UsersCookbook, \
    OtherInfo
from MendelLib.mendel_meta import (GLOBALS, number_, last_num_, father_, mother_, save_name_,
                                   saves_loaded_, f_, m_, r_, calc_data_, _saves_dir)
from MendelLib.result.xlsx_gen import xlsx_gen_from_save_main, xlsx_gen_main
from MendelLib.save.save_gen import gen_save_main
from MendelLib.save.save_read import read_save_main
from MStzzfTools.decorators import Timer
from MStzzfTools.file_util import get_dir
from MStzzfTools.printer import *



@Timer(1)
def calculate():
    GLOBALS[number_] = int(GLOBALS[number_])
    GLOBALS[last_num_] = GLOBALS[number_]
    cfather = GLOBALS[father_]
    cmother = GLOBALS[mother_]

    if GLOBALS[number_] == 9:
        fp1718 = cfather[9]
        mp1718 = cmother[9]
        cfather = cfather[:9]
        cmother = cmother[:9]
        GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_], GLOBALS[calc_data_][r_] = analyzeChessboard9(
            recursion_gamete(cfather, 8), recursion_gamete(cmother, 8),
            fp1718, mp1718
        )
    elif GLOBALS[number_] < 9:
        GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_], GLOBALS[calc_data_][r_] = analyzeChessboard(
            recursion_gamete(cfather, GLOBALS[number_]),
            recursion_gamete(cmother, GLOBALS[number_])
        )


# save #######################################################################################
def save_gen():
    """将计算结果保存在存档路径中，用于更好的读取和计算。"""
    if GLOBALS[last_num_] != 0 or GLOBALS[saves_loaded_]:
        save_name = ms_input("请输入存档名字：")
        save_credit = ms_input("请输入描述：")

        gen_save_main(GLOBALS[father_], GLOBALS[mother_],
                      GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_],
                      GLOBALS[calc_data_][r_], save_name, save_credit)
        GLOBALS[saves_loaded_] = True
    else:
        ms_error("<保存失败：没有进行任何的计算！>")


def save_read():
    """从指定的存档路径读取存档"""
    GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_], GLOBALS[calc_data_][r_], \
    GLOBALS[number_], GLOBALS[save_name_], \
    GLOBALS[father_], GLOBALS[mother_] = read_save_main(ms_input("请输入存档名字："))
    GLOBALS[saves_loaded_] = True


def save_calc():
    """计算/直接输出存档中的计算结果。"""
    if not GLOBALS[saves_loaded_]:
        ms_error("<错误：还没有读取任何存档！>")
    else:
        result_printer(GLOBALS[calc_data_][f_], '父本配子')
        result_printer(GLOBALS[calc_data_][m_], '母本配子')
        result_printer(GLOBALS[calc_data_][r_], '子代')


# result #######################################################################################
def result_gen():
    """将计算后的结果保存成受支持的格式。"""
    try:
        if GLOBALS[saves_loaded_]:
            xlsx_gen_from_save_main(GLOBALS[save_name_], "result-" + GLOBALS[save_name_], need_cwd=True)
        else:
            xlsx_gen_main([GLOBALS[father_], GLOBALS[mother_]],
                          [GLOBALS[calc_data_][f_], GLOBALS[calc_data_][m_], GLOBALS[calc_data_][r_]],
                          f"r{GLOBALS[father_]}-{GLOBALS[mother_]}", need_cwd=True)
    except NameError:
        ms_error("[错误]未读取任何存档或进行任何计算！")
    except:
        ms_error("[错误]发生意料之外的错误！")
        print_exc()
        ms_warn("[信息]通常有可能是没有安装\x1b[33mopenpyxl\x1b[0m库导致的。", True)



def save_list(mode=''):
    """获得被存档文件夹下的所有的文件夹"""
    try:
        f_list = [d for d in get_dir(_saves_dir) if "." not in d]
    except FileNotFoundError:
        ms_error("[错误]路径[/saves]不存在！")
    else:
        if mode[-2:] != '-s':
            printFiles(f_list)
        return f_list


def save_search():
    """搜索存档文件夹下含有关键词的文件"""
    key_word = ms_input("请输入关键词>")
    result_f = []
    f_list = save_list('-s')
    for s in f_list:
        if key_word in s:
            result_f.append(s)
    print("搜索关键词: '" + key_word + "'")
    if len(result_f) != 0:
        printFiles(result_f)
    else:
        ms_error("[信息]该关键词无结果.")
    return result_f


# about #######################################################################################
def about():
    """输出关于此项目的内容"""
    print(AboutProgram)


def aboutus():
    """输出关于开发者的内容"""
    print(AboutUs)


def cookbook():
    """输出关于使用此应用的方法"""
    print(UsersCookbook)


def otherinfo():
    """输出关于此应用的其他信息"""
    print(OtherInfo)


# misc #######################################################################################
def help_():
    """获得孟德尔计算器的所有命令的详细信息"""
    for f in __func__:
        print(f"\t[{f}]:" + __func__[f].__doc__)


def tests():
    """测试所有的功能(仅限命令行模式)"""
    GLOBALS[number_] = 2
    GLOBALS[father_] = "AaBb"
    GLOBALS[mother_] = "AAbb"
    calculate()
    for f in list(__func__.keys()):
        ms_green(f"[test]function:{f}")
        if f == "cls" or f == "test":
            ms_warn("[test]test skipped!")
            continue
        __func__[f]()


def cls():
    """清空屏幕，仅限windows系统"""
    if psys() == 'Windows':
        system("cls")
    else:
        print("<非Windows平台似乎不支持清屏功能！>")


# 这个函数字典是非常有效的，它会使你的代码量成倍的减少，它也算是动态扩展的一种应用。
# 一般人这么写：
'''
command = input()
if command == "exit": exit()
elif command == "haha": do114514()
elif command == "114514": print("臭死了。")
...以下省略一万个elif comand == ...
else:print("不存在此命令！！")
'''
# 实际上可以这么写(我这里没有把参数也存储进去，因为当时我不知道参数也可以是动态的。)
'''
__func__ = {"exit":(exit, (),       {}),            "haha":(do115514, (), {}), "114514":(print, ("臭死了。", ), {})...}
            命令名称 函数   函数的参数  函数的字典式参数
command = input()
if command in __func__:
    group = __func__[command]
    group[0](*group[1], **group[2])    # 输入exit时，这行等效于exit(), 输入114514时，这行等效于print(*("臭死了。", )),print("臭死了。")
else:
    print("不存在此命令！！")
'''

__func__ = {"save.gen": save_gen, "save.read": save_read, "save.calc": save_calc,
            "save.list": save_list, "save.search": save_search,
            "result.gen": result_gen,
            "cls": cls, "test": tests, "help": help_,
            "about": about, "about-us": aboutus, "cookbook": cookbook, "other-info": otherinfo,
            }
