"""允许导入上一级模块。"""
__author__ = "MStzzf"

from pathlib import Path
from sys import path as spath

spath.append(str(Path(__file__).resolve().parent))
# 我的工具库
spath.append(str(Path(__file__).resolve().parent.parent))
# for i in spath: print(i)
