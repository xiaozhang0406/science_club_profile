"""这里面的东西可以被拓展！
Python对动态的扩展非常的友好，所以为什么不写个插件系统呢？
实际上，在有GUI的版本中，_formats已经被用于动态扩展了，不信你去MendelLib/result/xlsx_gen.py里看一看。
"""
from MStzzfTools.printer import ms_warn
from MendelLib.result.html_gen import html_gen_from_save_main, html_gen_main
from MendelLib.result.txt_gen import txt_gen_main, txt_gen_from_save_main

_mo_presets = {}

_preset_genes = {
    "演示": [1, "Aa", "aa",
             "用最简单的数据演示测交。"],
    "三对等位基因": [3, "AaBbCc", "AaBbCc",
                     "几乎可以说是人计算耐力的上限。"],
    "绝望测试1": [8, "AaBbCcDdEeFfGgHh", "AaBbCcDdEeFfGgHh",
                  "[警告]如果你的电脑性能不怎么样，请不要花三十多秒去尝试这个！"],
    "绝望测试2": [9, "AaBbCcDdEeFfGgHhIi", "AaBbCcDdEeFfGgHhIi",
                  "[警告]如果你的电脑性能不怎么样，请不要花三十多秒去尝试这个！"],
}

_formats = {"txt": [txt_gen_from_save_main, txt_gen_main],
            "html": [html_gen_from_save_main, html_gen_main]}

_FORMATS = "formats"
_PRESET_GENES = "genes_preset"
_MOTHER_PRESET = "mother_presets"
_registry_index = {
    _FORMATS: _formats,
    _PRESET_GENES: _preset_genes,
    _MOTHER_PRESET: _mo_presets
}


def expand(old: str, d: dict):
    # todo:替换是被禁止的。未成功！
    old_dict = _registry_index[old]
    elements = set(old_dict.keys())
    d_elements = set(d.keys())
    repeated_key = set()
    for e in d_elements:
        if e in elements:
            repeated_key.add(e)
    if not repeated_key:
        _registry_index[old].update(d)
    else:
        ms_warn(f"[警告][注册][{d}]提供的重复的键将不会被加入到[{old}]中！")

        for e in d_elements.difference(repeated_key):
            _registry_index[old][e] = d[e]


if __name__ == '__main__':
    expand(_FORMATS, {"html": 2})
    print(_formats)
