from os import walk, path
from pathlib import Path


def collect_lines(p, file):
    global HowManyLines
    try:
        f = open(p, 'r', encoding="UTF-8")
        n = len(f.readlines())
        f.close()
        HowManyLines += n
        print("[" + file + "] -> [" + str(n) + "] lines!")
    except:
        pass


HowManyLines = 0
ig_list = ['.gitattributes', '.gitignore', 'blackhole.ico',
           'HowManyLines.py', 'mendel.spec', 'mendel_shared_program.py',
           'README.md', '__init__.py', '@test.py',
           'monitor_processor.py', 'pyi_generater.py'
           ]
if __name__ == "__main__":
    for root, dirs, files in walk(Path(__file__).resolve().parent):
        if 'venv' in dirs:
            dirs.remove('venv')
        for file in files:
            if file not in ig_list and '.py' in file:
                collect_lines(path.join(root, file), file)
    print("一共%s行！" % HowManyLines)
