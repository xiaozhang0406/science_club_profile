"""有关此程序的信息。
参考代码中的这个文件不能替代代码库中的文件！
所以你只能从这里一窥它的内容。
算是调用的接口吧。
在程序中调用这里的东西时，请不要直接导入这个文件，而是去导入代码库中这个文件对应的.pyd版本。
如果PyCharm或者别的IDE报错，可以不理会。
运行的时候报错，那可能是你修改了不该修改的东西。
如果程序从来没有经过修改，但是崩溃了，能自己解决的自己解决，不能就给我发电子邮件。
"""
from typing import List

from MStzzfTools.tk import WinGeo
# 我们在这里将MendelLib.mendel_settings获得的设置提交到MStzzfTools.toolsConfig的_decorator中。

# meta #######################
# 程序的元数据存储区
_meta_version = None
_build = None

_META = {
    _meta_version: None,
    _build: None
}


def version_maker(v: tuple):
    """返回一个格式化的版本字符串。"""
    pass


# directories ###############
_saves_dir: str = None
_cache_dir: str = None
_saves:List[str] = [None]


def upd_saves() -> None:
    """获取存档目录下的所有存档。"""
    pass


# gui #######################
_title: str = None
# 窗口大小
_geo = WinGeo(450, 600, 800, 50)
min_geo = WinGeo(450, 600)
max_geo = WinGeo(620, 710)
min_geo_top = WinGeo(240, 160)
max_geo_top = WinGeo(365, 185)
min_geo_top1 = WinGeo(240, 320)
max_geo_top1 = WinGeo(365, 475)
_ico = "./icon.ico"   # 图标文件

# GLOBALS #################
# GLOBALS存储了应用程序在运行时的所有数据。
# 如果你要访问GLOBALS的值，你可以使用下方的这些快速定义来访问。
# 比如 if GLOBALS[exit_]: exit() 这行的意思就是，如果GLOBALS的exit_对应的值是真，则退出程序。

exit_           = None
number_         = None
last_num_       = None
father_         = None
mother_         = None
save_name_      = None
saves_loaded_   = None
gui_            = None

calc_data_ = None
f_ = None
m_ = None
r_ = None

GLOBALS = {
    exit_: False,
    number_: 1,
    last_num_: 0,
    father_: '',
    mother_: '',
    save_name_: '',
    saves_loaded_: False,
    gui_: None,     # 存储一个GUI窗口，GUI版本下有效
    calc_data_: {
        f_: None,
        m_: None,
        r_: None
    }
}


def set_exit():
    """线程钩子"""
    GLOBALS[exit_] = True


def is_exit():
    """线程钩子"""
    return GLOBALS[exit_]


_site = None
