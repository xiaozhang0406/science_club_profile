﻿"""提供了绝大多数的函数运行辅助
参考代码中的这个文件不能替代代码库中的文件！
所以你只能从这里一窥它的内容。
算是调用的接口吧。
在程序中调用这里的东西时，请不要直接导入这个文件，而是去导入代码库中这个文件对应的.pyd版本。
如果PyCharm或者别的IDE报错，可以不理会。
运行的时候报错，那可能是你修改了不该修改的东西。
如果程序从来没有经过修改，但是崩溃了，能自己解决的自己解决，不能就给我发电子邮件。
"""

from functools import lru_cache
from typing import List

from MStzzfTools.decorators import _pass
from MStzzfTools.mtype_util import *


def mendel_ord(char:str) -> int:
    """使用自定义的字符列表
    返回该字母在自定义字母表的位置，如mendel_ord("A") -> 0, mendel_ord("a") -> 1, mendel_ord("B") -> 2, 以此类推。
    """
    pass


def get_alpha_ignore_case(g: str) -> List[str]:
    """获得每个基因型的代表符号, 总是返回小写
    如'AaHh' -> [a, h]
    """
    pass


def isAA(g: str) -> bool:
    """它是纯合显性的吗？"""
    pass


def isaa(g: str) -> bool:
    """它是纯合隐性的吗？"""
    pass


def isAa(g: str) -> bool:
    """它是杂合的吗？"""
    pass


@lru_cache(maxsize=64)
def matcher(str1: str, str2: str) -> str:
    """通过mendel_ord()返回的值对字母进行排序，使大写在前，小写在后"""
    pass


def printFiles(f_list) -> None:
    """输出文件列表"""
    pass


def mendel_min(li: List[int]) -> int:
    """获得一个列表的最小值"""
    pass


def rater(dicted: dict[str, int]) -> dict[str, int]:
    """针对配子进行简化比率使计算更快。对于结果的简化只是为了看起来舒服。"""
    pass


def recursion_gamete(gene: str, num: int, rgamete_list: list = [], statue=0) -> List[str]:
    """使用递归获取一个父本/母本的配子。
    调用时只需要填入gene(基因)和num(等位基因数)就够了，后面两个是用于递归的。
    """
    pass


def isIllegalGenes(n: int, father: str, mother: str, return_info: bool = False, silent: bool = False):
    """判断等位基因数、父本基因和母本基因是否符合要求.
    返回信息有以下几种：
    父本或母本的基因长度似乎不是等位基因数的两倍。
    父本与母本似乎不等长。
    父本或母本似乎不符合二倍体要求。
    :param n: 等位基因数
    :param father: 父本基因
    :param mother: 母本基因
    :param return_info: 是否返回错误信息？
    :param silent: 是否不直接输出信息？
    """
    pass

def isIllegalCommand(cmd: str, return_info: bool = False, silent: bool = False):
    """检查输入的命令的合法性
    返回信息有以下几种：
    "输入不能为空！"
    "请输入一个一位自然数！"
    """
    pass


def isIllegalSaveName(sn: str, return_info: bool = False, silent: bool = False):
    """检查文件名的合法性，
    返回信息有一下几种：
    "文件名不应包含. / \\ : * ? \" < > |这些符号之一！"
    "此名字已被其他存档或文件占用！"
    """
    pass


class Callbacks:
    """回调函数的集合"""
    class AnalyzeChb:
        """专用于mendel_console.analyzeChessboard()和mendel_console.analyzeChessboard9()函数的回调函数集合
        gamete_l2d: CBIteration
        on_match: func() void.
        match_l2d: CBIteration（参见MStzzfTools.mtype_util.CBIteration类）
        on_finalise: CBIteration, incl. -> start: before_finalise: func(_dict)
                                           foreach: on_finalise: func(index, key)
        """

        def __init__(self, gamete_l2d: CBIteration = CBIteration(),
                     on_match=_pass, match_l2d: CBIteration = CBIteration(),
                     on_finalise: CBIteration = CBIteration()):
            if not callable(on_match):
                raise TypeError("[AnalyzeChb]param: on_match are not callable!")
            self.gamete_l2d = gamete_l2d
            self.onmatch = on_match
            self.match_l2d = match_l2d
            self.on_finalise = on_finalise

        def onGameteL2dDo(self, cbi: CBIteration):
            self.gamete_l2d = cbi
            return self

        def onMatchDo(self, func):
            are_callable(func, "[AnalyzeChb]The given params is not callable!")
            self.onmatch = func
            return self

        def onMatchL2dDo(self, cbi: CBIteration):
            self.match_l2d = cbi
            return self

        def onFinaliseDo(self, cbi: CBIteration):
            self.on_finalise = cbi
            return self



AboutProgram = None #关于此程序:


AboutUs = None # 关于我们:

UsersCookbook = None #使用说明书:

OtherInfo = None #其他信息:


