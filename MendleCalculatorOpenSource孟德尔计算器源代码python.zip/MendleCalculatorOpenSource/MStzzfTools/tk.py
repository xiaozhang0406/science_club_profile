"""一些非常有用的GUI工具，尤其是WinGeo"""

from tkinter import *


def tkgeo_formater(w:int, h:int, offset_x:int=0, offset_y:int=0):
    return "%dx%d+%d+%d" % (int(w), int(h), int(offset_x), int(offset_y))


class WinGeo(object):

    def __init__(self, w:int=0, h:int=0, offset_x:int=0, offset_y:int=0):
        self._h = h
        self._w = w
        self._ox = offset_x
        self._oy = offset_y

    @staticmethod
    def create_from_string(s:str):
        """create from a tk-geo-like string
        like: 114x514+1919+810 or 114514x1919810
                 ^   ^    ^             ^
        """
        x_pos = s.find("x")
        add_pos = s.find("+")
        if x_pos<0:
            raise Exception("[ERROR]The given string[%s] lost [x]"%s)
        else:
            if add_pos>=0:
                xy_part = s[add_pos:].split("+")
                s = s[:add_pos]
                xy_part = [string for string in xy_part if string != ""]
                if len(xy_part) == 2:ox, oy = xy_part
                else: raise Exception("[ERROR]Not a tk-geo-like string[%s]"%s)
            else:
                ox = oy = 0

            wh_part = s.split("x")
            if len(wh_part) == 2: w, h = wh_part
            else: raise Exception("[ERROR]Not a tk-geo-like string[%s]" % s)

        return WinGeo(int(w), int(h), int(ox), int(oy))

    def move(self, x:int=0, y:int=0):
        """change itself"""
        if self.ox + x < 0 or self.oy + y < 0:
            raise Exception("[ERROR]offset should larger than 0!")
        else:
            self._ox+=x
            self._oy+=y
            return self
    def set_offset(self, x:int=0, y:int=0):
        if x < 0 or  y < 0:
            raise Exception("[ERROR]offset should larger than 0!")
        else:
            self._ox=x
            self._oy=y
            return self

    def move2center(self, screen_w, screen_h):
        """change itself."""
        wh = int(screen_h / 2)
        ww = int(screen_w / 2)
        h = int(self.h / 2)
        w = int(self.w / 2)
        self._ox = ww-w
        self._oy = wh-h
        return self

    def get_center(self, screen_w, screen_h):
        """return another object that moved to center."""
        obj = self
        return obj.move2center(screen_w, screen_h)

    def get_win_center(self, window):
        wingeo = self.__class__.create_from_string(window.winfo_geometry())
        w, h = wingeo.size
        x, y = wingeo.offset
        return self.get_win_center2(w, h, x, y)

    def get_win_center2(self, w, h, x, y):
        obj = self
        return obj.get_center(w, h).move(x, y)


    @property
    def h(self):
        return self._h
    height = h
    @property
    def w(self):
        return self._w
    weight = w
    @property
    def ox(self):
        return self._ox
    offset_x = ox
    @property
    def oy(self):
        return self._oy
    offset_y = oy
    @property
    def tk_geometry(self):
        return tkgeo_formater(self.w, self.h, self.ox, self.oy)
    @property
    def size(self):
        return self.w, self.h
    @property
    def offset(self):
        return self.ox, self.oy

    def __repr__(self):
        return "WinGeo[w=%s, h=%s, offsetx=%s, offsety=%s]" % (self.w, self.h, self.ox, self.oy)
    def __str__(self):
        return "WinGeo[w=%s, h=%s, offsetx=%s, offsety=%s]" % (self.w, self.h, self.ox, self.oy)
    def __eq__(self, other):
        if isinstance(other, WinGeo): return self.w == other.w and self.h == other.h and self.ox == other.ox and self.oy == other.oy
        else: return str(self) == str(other)
    def __ne__(self, other):
        return not self.__eq__(other)


def set_value(t: Text, string: str):
    t.delete(1.0, END)
    t.insert(INSERT, string)

set_text_value = set_value

def get_value(t: Text):
    return t.get(1.0, END).replace("\n", "")
get_text_value = get_value

