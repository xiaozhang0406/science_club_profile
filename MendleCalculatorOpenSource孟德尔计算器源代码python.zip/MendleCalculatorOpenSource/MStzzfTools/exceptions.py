"""错误
其实没什么用，但是我懒得改了，好麻烦。。。。。。
"""

class MSError(Exception):
    def __init__(self, arg:str='', msg:str='', callback=print, args:tuple=tuple()):
        Exception.__init__(self, arg)
        self.msg = msg
        if callable(callback):
            callback(args)


SaveError = LoadError = MSError


