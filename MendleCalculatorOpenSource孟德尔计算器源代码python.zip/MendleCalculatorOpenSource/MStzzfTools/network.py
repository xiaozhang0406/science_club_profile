﻿"""有关网络的部分，需要第三方库requests，在这个程序中的应用仅仅是从网络上下载更新文件，检查更新而已。"""
from os import chdir, getcwd
from traceback import format_exc

_disable = False

try:
    import requests
except ImportError:
    _disable = True
    print("[错误]导入第三方库requests和tqdm时发生了错误！将禁用部分功能！")
    print(format_exc())

from MStzzfTools.decorators import DisableCondition
from MStzzfTools.file_util import _byte_overwrite

_disable_error = "[错误]此函数已被禁用！"

@DisableCondition(_disable, _disable_error)
def silent_download(url:str, fn:str, overwrite:bool=False):
    try:
        r = requests.get(url, stream=True, allow_redirects=True)
    except requests.ConnectionError:
        return False
    else:
        return _silent_dl_write(fn, r, overwrite)

@DisableCondition(_disable, _disable_error)
def _silent_dl_write(fn:str, r, overwrite:bool=False):
    mode = _byte_overwrite(overwrite, fn)
    try:
        with open(fn, mode) as f:
            for ch in r:
                # 这边的type警告就不要管他了
                f.write(ch)
                f.flush()
            f.close()
    except FileExistsError:
        return False
    except FileNotFoundError:
        return False
    except Exception:
        return False
    else:
        return True

