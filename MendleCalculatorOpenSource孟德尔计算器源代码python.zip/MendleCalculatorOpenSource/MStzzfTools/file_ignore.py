"""getAllFile()忽略清单"""
python_ig = [
    "/.idea",
    "/.git",
    "/__pycache__",
    ".pyd",
    ".pyc"
]

java_ig = [
    ".class"
]

