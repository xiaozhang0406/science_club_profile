"""颜色区分功能仅在win10环境下可用！！！"""
from platform import release as pr
from platform import system as ps

PLATFORM = ps()
RELEASE = pr()
# print(PLATFORM, RELEASE)

class formats:
    white = "\x1b[0m"
    yellow = "\x1b[33m"

    @staticmethod
    def format_y(s:str): return "\x1b[33m"+s+"\x1b[0m"



def ms_warn(s: str, mode=False):
    """黄色输出"""
    if PLATFORM == "Windows" and RELEASE == "10":
        s = s+formats.white if mode else formats.format_y(s)
    else:
        s = s.replace(formats.white, "").replace(formats.yellow, "") if mode else s

    print(s)



def ms_error(s: str):
    """红色输出"""
    if PLATFORM == "Windows" and RELEASE == "10":print("\x1b[91m"+s+"\x1b[0m")
    else:print(s)


def ms_green(s:str):
    """绿色输出"""
    if PLATFORM == "Windows" and RELEASE == "10":print("\x1b[32m"+s+"\x1b[0m")
    else:print(s)


def ms_input(s: str) -> str:
    """输入的字为绿色"""
    if PLATFORM == "Windows" and RELEASE == "10":
        ans = input("\x1b[0m"+s+"\x1b[32m")
        print("\x1b[0m", end="")
        return ans
    else:
        return input(s)

