"""一些有用的文件目录处理功能"""
import json
from json.decoder import JSONDecodeError
from os import getcwd, listdir, walk, mkdir, path, rename
from pathlib import Path

from .exceptions import LoadError, SaveError
from .printer import *
from .file_ignore import python_ig


def loadJsonFile(file_name: str, no_e=False, need_cwd=True) -> (dict, bool):
    """加载json文件，返回字典和布尔值（是否加载成功）"""
    if need_cwd:
        p = (getcwd() + file_name).replace("\\", "/")
    else:
        p = file_name.replace("\\", "/")
    try:
        with open(p, 'r', encoding='utf-8') as file:
            config_str = file.readlines()
            file.close()
            config_string = ''
            for line in config_str:
                config_string += line
            json_dict = json.loads(config_string)
            return json_dict, True
    except FileNotFoundError:
        ms_error("<加载失败：[" + file_name + "]不存在!>")
        if not no_e:
            raise LoadError
    except JSONDecodeError as JE:
        JsonDecodeErrorHelper(JE, file_name)
        if not no_e:
            raise LoadError
    except:
        ms_error("<加载失败：加载[" + file_name + "]时发生意外错误!>")
        if not no_e:
            raise LoadError


def saveJsonFile(file_name: str, data: dict, mode: str, need_cwd=True, no_e=False):
    """保存json文件
    mode -> 'a'  or  'w'  or  'x'  (+)"""
    if isinstance(file_name, Path):
        p  = file_name.resolve()
    else:
        if need_cwd:
            p = (getcwd() + file_name).replace("\\", "/")
        else:
            p = file_name.replace("\\", "/")
    try:
        with open(p, mode, encoding='utf-8') as file:
            file.writelines(json.dumps(data, indent=2))
            file.flush()
            file.close()
            print(f"<[{file_name}]已成功被创建/写入!>")
    except FileNotFoundError:
        ms_error(f"<构建失败：没有找到[{p}]文件>")
        if not no_e:
            raise SaveError
    except FileExistsError:
        ms_error(f"<构建失败: [{p}]文件已存在！！>")
        if not no_e:
            raise SaveError
    except:
        ms_error("<构建失败：发生了意料之外的错误！>")
        if not no_e:
            raise SaveError


def get_dir(p: str, mode='', key_word='') -> list:
    """搜索路径返回所有满足条件的"""
    fp = str(p.resolve()) if isinstance(p, Path) else str(p).replace("\\", "/")
    try:
        # print(fp)
        f_list = listdir(fp)
    except FileNotFoundError:
        ms_error("[错误]路径[%s]不存在！" % fp)
        return []
    else:
        result_f = []
        if mode == '-s':
            for s in f_list:
                if key_word in s:
                    result_f.append(s)
        else:
            result_f = f_list
        return result_f


def getAllFile(p: str, ignore:list=None):
    if ignore is None:
        ignore = python_ig
    raw = []
    file_list = []
    flag = True
    for root, dirs, files in walk(p):
        for f in files:
            raw.append((root+"/"+f).replace("\\", "/"))
        #print(root, dirs, files)
    #print(raw)

    for findex in range(len(raw)):
        for ig in ignore:
            if ig in raw[findex]:
                flag = False
                break
            flag = True
        if flag:
            file_list.append(raw[findex])

    return file_list

def get_all_file_key(p: str, key:str):
    raw = []
    file_list = []
    for root, dirs, files in walk(p):
        for f in files:
            raw.append((root + "/" + f).replace("\\", "/"))
        # print(root, dirs, files)
    # print(raw)

    for findex in range(len(raw)):
        if key in raw[findex]:
            file_list.append(raw[findex])

    return file_list


def makedir(mk_path) -> int:
    mk_path = mk_path.strip()
    mk_path = mk_path.rstrip("\\")

    # 判断结果
    if not path.exists(mk_path):
        # 如果不存在则创建目录
        # 创建目录操作函数
        mkdir(mk_path)
        print("[信息]["+mk_path + "]已成功被创建!>")
        return 1
    return 0


def _byte_overwrite(ow:bool, p:str):
    return 'xb' if not ow and path.exists(p) else 'wb'


def _overwrite(ow:bool, p:str):
    return 'x' if not ow and path.exists(p) else 'w'


def noFileHelper(file, mode=''):
    print("<错误：无法找到文件[{}]!>".format(file))
    if mode == 'imp':
        input('<type anything to exit!>')
        exit()


def LostSthHelper(file, mode='', e: Exception = None):
    print("<错误：文件[{}]似乎不完整!>".format(file))
    if e != None:
        print("[信息]可能的错误>" + str(e.args).replace('(\'', '').replace('\',)', '') + ">")
    if mode == 'imp':
        input('<type anything to exit!>')
        exit()


def JsonDecodeErrorHelper(je: JSONDecodeError, file: str):
    ms_error(f"<加载失败：json文件[{file}]无法读取！>")
    ms_error("详细信息：可能的错误>" + str(je.args).replace('(\'', '').replace('\',)', ''))


def KeyErrorHelper(e: KeyError, name: str):
    ms_error("[错误]文件[" + name + "]不完整！")
    ms_error("[信息]可能的缺少的键>" + str(e.args))
