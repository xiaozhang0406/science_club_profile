"""测试我的函数库。这个文件测试MStzzfTools/tk.py的WinGeo类。"""
import unittest

from MStzzfTools.tk import *


class TestWinGeo(unittest.TestCase):

    def test_create_from_string(self):
        self.assertEqual(WinGeo.create_from_string('240x160'), WinGeo(240, 160))
        self.assertEqual(WinGeo.create_from_string('240x160+114+514'), WinGeo(240, 160, 114, 514))

    def test2center(self):
        sc = [200, 150]
        o1 = WinGeo(100, 100)
        o2 = WinGeo(50, 50)
        self.assertEqual(o1.move2center(*sc), WinGeo(100, 100, 50, 25))
        self.assertEqual(o2.move2center(*sc), WinGeo(50, 50, 75, 50))
        self.assertEqual(o1.get_center(*sc), WinGeo(100, 100, 50, 25))
        self.assertEqual(o2.get_center(*sc), WinGeo(50, 50, 75, 50))
        sc = [600, 100]
        self.assertEqual(o1.move2center(*sc), WinGeo(100, 100, 250, 0))
        self.assertEqual(o2.move2center(*sc), WinGeo(50, 50, 275, 25))

    def test2WinCenter(self):
        pos1 = (100, 100, 50, 50)
        pos2 = (100, 200, 100, 50)

        o1 = WinGeo(100, 100)
        o2 = WinGeo(50, 50)

        self.assertEqual(WinGeo(100, 100, 50, 50), o1.get_win_center2(*pos1))
        self.assertEqual(WinGeo(50, 50, 75, 75), o2.get_win_center2(*pos1))

        self.assertEqual(WinGeo(100, 100, 100, 100), o1.get_win_center2(*pos2))
        self.assertEqual(WinGeo(50, 50, 125, 125), o2.get_win_center2(*pos2))

    def test_tk_formater(self):
        o1 = WinGeo(100, 100)
        o2 = WinGeo(50, 50)
        self.assertEqual(o1.tk_geometry, "100x100+0+0")
        self.assertEqual(o2.tk_geometry, "50x50+0+0")
        o1 = WinGeo(100, 100, 114514, 0)
        o2 = WinGeo(50, 50, 1919, 810)
        self.assertEqual(o1.tk_geometry, "100x100+114514+0")
        self.assertEqual(o2.tk_geometry, "50x50+1919+810")

    def test_offset(self):
        o1 = WinGeo(100, 100)
        o2 = WinGeo(50, 50, 1919, 810)
        self.assertEqual(o1.move(50, 25), WinGeo(100, 100, 50, 25))
        self.assertRaises(Exception, o1.move(-3, 0))
        self.assertRaises(Exception, o1.move(3, -10))
        self.assertEqual(o2.move(50, 25), WinGeo(50, 50, 1969, 835))
        self.assertRaises(Exception, o2.move(-1920, 0))
        # 为啥这两个偏偏会报错。。。。
        # self.assertRaises(Exception, o2.move(3, -910))
        # self.assertRaises(Exception, o2.move(-1919, -810))


if __name__ == '__main__':
    unittest.main()
