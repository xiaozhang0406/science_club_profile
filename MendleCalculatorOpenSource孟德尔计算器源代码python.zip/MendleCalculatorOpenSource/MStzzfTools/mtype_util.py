"""转化数据类型的一些小工具。"""

# print("mtype")
# 注意，如果函数参数是一个列表或字典，那么就不能用函数缓存。。。。
from MStzzfTools.decorators import _pass


class CBIteration:
    """回调函数集合，包含一个在循环前调用的函数 和 在循环中为每一个元素调用的函数
    具体实现方法可以看ListToDict函数和 DictToList函数
    """

    def __init__(self, on_start=_pass, for_each=_pass):
        """note that diff type lead to diff call
        if List2Dict:
            on_start: func(_list, _set, _dict)
            for_each: func(index, [element from _set],_list, _set, _dict)
        else:
            on_start: func(_dict, _list)
            for_each: func(index, element, _dict, _list)
        """
        if not (callable(on_start) and callable(for_each)):
            raise TypeError("[CBIteration]on_start or for_each is not callable!!")
        self.onstart = on_start
        self.foreach = for_each

    def onStartDo(self, func):
        if not callable(func):
            raise TypeError("[Callbacks.CBIteration]func is not callable!!")
        self.onstart = func
        return self

    def forEachDo(self, func):
        if not callable(func):
            raise TypeError("[Callbacks.CBIteration]func is not callable!!")
        self.foreach = func
        return self


def ListToDict(_list: list, callback: CBIteration = CBIteration()) -> dict:
    """将一个列表转化为字典。"""
    _dict = {}
    _set = set(_list)
    callback.onstart(_list, _set, _dict)

    for index, eum in enumerate(_set):
        _dict[eum] = _list.count(eum)

        callback.foreach(index, eum, _list, _set, _dict)

    return _dict


def DictToList(_dict: dict, callback: CBIteration = CBIteration()) -> list:
    """去字典化"""
    _list = []
    callback.onstart(_dict, _list)
    for index, element in enumerate(_dict):
        _list.extend([element] * _dict[element])
        callback.foreach(index, element, _dict, _list)
    return _list


def are_callable(_list, error=""):
    for i in _list:
        if not callable(i):
            if error!="":
                raise TypeError(error)
            return False
    return True

