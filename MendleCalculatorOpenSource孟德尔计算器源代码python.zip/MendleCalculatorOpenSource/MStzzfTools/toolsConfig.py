"""我的工具库的配置，需要主程序在使用时注册和配置。
那个using_gui的两个函数是我设计的失败品，但是不能删除，会导致错误——这就是为什么我说它失败。

如果你要用函数装饰器，请务必导入我
(default value)
global incl.:
    gui:false

"""
from traceback import format_exc

_global = "global"
_gui = "gui"

_decorator = "decorator"

_CFG = {
    _global: {
        _gui: False
    },
    _decorator: dict()

}


def update_config(symbol: str, upd: dict):
    """更新配置"""
    # TODO：添加一个监测机制，不能让config的值被替换了
    for k in set(upd.keys()):
        if k in _CFG[symbol]:
            print("[ERROR]There exists the same key in _CFG[%s]!Could not replace it!" % symbol)
            return
    _CFG[symbol].update(upd)


tk_exists = False

# 勿删
def set_using_gui():
    global _CFG, tk_exists
    try:
        import tkinter
    except Exception:
        print("[ERROR]Error while trying import tkinter!")
        print(format_exc())
        _CFG[_global][_gui] = False
    else:
        tk_exists = True
        _CFG[_global][_gui] = True
        del tkinter

# 勿删
def is_using_gui(force=False):
    global _CFG
    b = _CFG[_global][_gui]
    b = b or tk_exists if force else b
    return b


if __name__ == '__main__':
    pass
