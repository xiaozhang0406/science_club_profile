"""函数装饰器
逻辑比较复杂，鼠疫比较高深的一块，下面的区域建议以后再来探索。
"""
from functools import wraps
from time import time_ns

from sys import argv
from getopt import getopt

import MStzzfTools.toolsConfig as tc
from MStzzfTools.printer import ms_error


class WrapperBase(object):
    def __init__(self, hasArg: int, defalut_return:tuple=tuple()):
        self.hasArg = hasArg
        self._default_return = defalut_return

    def __call__(self, func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapped_function


class Timer(WrapperBase):
    """计时器"""
    def __init__(self, hasArg: bool):
        super().__init__(hasArg)

    def __call__(self, func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            _d1 = time_ns()
            rs = func(*args, **kwargs)
            dt = round((time_ns() - _d1) / 1000000, 3)
            if dt > 1000:
                info = f"[信息]{func.__name__}共使用{str(round(dt / 1000, 2))}秒！"
            else:
                info = f"[信息]{func.__name__}共使用{str(dt)}毫秒！"

            print(info)

            return rs

        return wrapped_function


def _pass(*args, **kwargs):
    """啥都不做"""
    pass

def _do_this(*args, **kwargs):
    """指定为这个函数会被替换为被标记的函数"""
    pass

_YES = "yes"
_NO = "no"
_NULL = "null"


class BoolControl(WrapperBase):
    """使用设置文件中的布尔值来控制目标的执行"""
    _func = {}

    def __init__(self, hasArg:bool or int, name:str, yesdo, nodo,
                 yes:tuple=tuple(), no:tuple=tuple(), default_return:tuple=tuple()):
        super().__init__(hasArg, default_return)
        self._name = name
        if callable(yesdo):
            self._func[_YES] = (yesdo, yes)
        else:
            raise TypeError("[ERROR][MStzzfTools]yesdo is not callable!")
        if callable(nodo):
            self._func[_NO] = (nodo, no)
        else:
            raise TypeError("[ERROR][MStzzfTools]nodo is not callable!")

    def __call__(self, func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            if tc._CFG[tc._decorator].get(self._name) is None: self.do_null()

            if tc._CFG[tc._decorator].get(self._name):
                if self._func[_YES][0] == _do_this:
                    return func(*args, **kwargs)
                elif self._func[_YES][0] != _pass:
                    return self._func[_YES][0](*self._func[_YES][1])
            else:
                if self._func[_NO][0] == _do_this:
                    return func(*args, *kwargs)
                elif self._func[_NO][0] != _pass:
                    return func[_NO][0](*self._func[_NO][1])


        return wrapped_function

    def do_null(self, func, args, kwargs):
        raise NameError("[ERROR]%s does not exist! (calling %s)" % (self._name, func.__name__))


class DisableCondition(WrapperBase):

    """如果提供的值是真，那么不执行，若为假，则执行被包装的函数"""

    def __init__(self, static_disable:bool, error_str:str=None):
        self.disable = static_disable
        self.error = error_str

    def __call__(self, func):
        @wraps(func)
        def wrapped_function(*args, **kwargs):
            if self.disable:
                if self.error is not None:
                    ms_error(self.error.replace("此函数", func.__name__))
            else:
                return func(*args, **kwargs)
        return wrapped_function

