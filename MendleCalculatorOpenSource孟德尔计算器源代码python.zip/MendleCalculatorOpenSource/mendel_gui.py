#!/usr/bin/python3
# -*- coding: UTF-8 -*-

# 所有的独立程序都建议写第一行(我没记错的话，这个叫shebang)。这样对跨系统运行有帮助。
# 参见https://www.cnblogs.com/z-x-y/p/11445650.html

# 所有文件都建议写第二行。它设置了文件的编码格式，设置成utf-8对国际化有帮助。

"""tk主页面"""
import sys
from os import system, chdir, getcwd
from pathlib import Path
from traceback import print_exc

from MendelLib.mendel_helper import _site  # 其实是来自mendel_meta的。导入它是为了把gui实例创建一下。
from MendelLib.mendel_meta import version_maker, GLOBALS, gui_

from MStzzfTools.printer import *

try:
    if sys.version_info.major != 3 or sys.version_info.minor < 8:
        ms_warn("<\x1b[33m__警告__\x1b[0m:此程序的解释器版本应该大于等于\x1b[33m3.8\x1b[0m！>", True)
except:
    pass

# 解决循环导入，从cmd_compact拷贝。
def getwin():
    """从GLOBALS获取GUI的实例"""
    if GLOBALS[gui_] is not None:
        return GLOBALS[gui_]
    else:
        raise RuntimeError("[ERROR]Fail to get window instance!")


def main():
    if PLATFORM == "Windows":
        system("title 孟德尔计算器-" + version_maker())
    chdir(Path(__file__).resolve().parent)
    print("workspace@" + getcwd(), "platform@" + PLATFORM)
    print("欢迎使用孟德尔计算器！")

    try:
        # 注册GUI（图形用户操作界面）的地方。
        gui = getwin()
        from MendelLib.gui.gui import LogicThread
        logic_thread = LogicThread(gui)
        logic_thread.start()
        gui.mainloop()
    except Exception as e:
        if isinstance(e, SystemExit):
            ms_warn("[信息]检测到发生的错误为SystemExit，如果你是手动退出，请无视这个错误。")
        ms_error("[错误]在运行孟德尔计算器的时候发生了错误，信息如下！")
        ms_error("workspace@" + getcwd() + "  platform@" + PLATFORM)
        print_exc()
        ms_green(f"[提示]如果您觉得这是个漏洞，请在[{_site}issues/]告诉我们，并提供以上信息，我们感激不尽。")
        input("<按回车键退出>")

# 这个判断语句的意思是如果这个文件作为主程序运行，则。。。
if __name__ == '__main__':
    main()
