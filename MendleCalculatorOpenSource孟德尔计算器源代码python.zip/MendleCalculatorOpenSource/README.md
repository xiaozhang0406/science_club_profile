# 孟德尔计算器
[![Documentation Status](https://readthedocs.org/projects/mendelcalculatordoc/badge/?version=latest)](https://mendelcalculatordoc.readthedocs.io/zh_CN/latest/?badge=latest)

    一个以解决高中生物的杂交类问题为目的的计算器，但是很理论化。
    邮箱: meteorshower1012@qq.com

运行程序方式：点击 _**mendel.py(无GUI)**_ 或者 _**mendel_gui.py(有GUI)**_ 。
